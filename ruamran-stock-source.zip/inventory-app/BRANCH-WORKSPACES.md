# Branch workspaces

Deployed GitHub Pages commit: 8b20e774d9f20017078d17d4ea650d491f887e44.
Database migration: 20261002055825_branch_workspaces_and_access_scopes.sql.

Products, suppliers and categories require branch_id. Prices inherit the product branch. Templates live in branch_settings. Existing 184 products and 14 categories belong only to สยามสุกี้ / ทิพย์เนตร. Original product fields and active states were preserved; no stock balances or movements were created.

Admins access all branches. Store managers require explicit store assignments; branch managers, staff and legacy operator/viewer accounts require explicit branch assignments. No assignment grants no branch access. RLS protects reads, guarded RPC protects writes, and triggers reject cross-branch master/price/stock links. Ordinary clients have no direct write grants. Access assignments can only be changed by an admin through the member-management command.

The UI requires an explicit store and branch. Reports and master settings require a manager/admin; organization-wide administration is admin-only. Receiving, issuing and counting are blank pending a new design. Existing database workflows remain tested for future forms. Detailed approval rules remain outside this change.

Validation completed:
- TypeScript noEmit and GitHub Pages build.
- branch-access.sql: staff/store-manager/branch-manager/admin scopes, immediate reassignment, outsider isolation, denied cross-branch requests and direct writes, manager CRUD and idempotency; rollback-only fixtures.
- phase1_workflows.sql and organization-roles.sql passed with branch-scoped fixtures.
- Inventory calculations/template/date tests passed with Node type stripping.
- Online UI verified: ทิพย์เนตร 142 active products; หลัง มช. 0 products; all three redesigned pages blank; admin member panel loaded.

Private before-change backup: private-backups/branch-separation-before.json (excluded from published zip and Git).
