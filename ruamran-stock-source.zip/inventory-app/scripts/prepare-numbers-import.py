"""Prepare product master data from the inspected legacy Numbers layout.
Read-only source. Counts/order suggestions stay out of branch_stock.
"""
import json, uuid
from pathlib import Path
source=json.loads(Path('/tmp/ruamran-numbers-data.json').read_text())
unit_map={'โล':'กก.','กิโล':'กก.','เเพ็ค':'แพ็ค','เเผง':'แผง','เเกลอน':'แกลลอน','เเกลลอน':'แกลลอน'}
records=[];excluded=[]
for table in source:
 rows=table['rows'];sheet=table['sheet']
 if sheet=='CS1สยามสุกี้':
  for col in [0,7]:
   category=None
   for rownum,row in enumerate(rows,1):
    name=row[col]
    if not isinstance(name,str) or not name.strip():continue
    name=name.strip()
    if name.startswith(('CS1','วันที่')) or name=='ผลิตภัณฑ์':continue
    if name in ['ผัก','เนื้อสัตว์','น้ำจิ้ม','ติ่มซำ','อื่นๆ','ชาไทย','น้ำหวาน','ซอส','ไอติม','ของหวาน','ตลาด'] and all(v is None for v in row[col+1:col+5]):
     category=name;continue
    if category=='ตลาด':
     excluded.append({'sheet':sheet,'row':rownum,'text':name,'reason':'ข้อความท้ายตารางตลาด อาจเป็นชื่อและจำนวนสั่ง ไม่ใช่ข้อมูลสินค้าครบถ้วน'});continue
    unit=row[col+4];unit=unit_map.get(unit,unit)
    records.append({'sheet':sheet,'row':rownum,'category':category,'original_name':name,'name':name,'unit':unit,'source_max':row[col+1]})
 else:
  for rownum,row in enumerate(rows,1):
   if rownum>=4:
    name=row[1]
    if isinstance(name,str) and name.strip() and name!='ผลิตภัณฑ์':
     records.append({'sheet':sheet,'row':rownum,'category':'เครื่องปรุง' if rownum<6 else 'อุปกรณ์และของใช้','original_name':name.strip(),'name':name.strip(),'unit':None,'source_max':None})
   if rownum>=4:
    name=row[7]
    if not isinstance(name,str) or not name.strip():continue
    name=name.strip()
    if name=='Delivery':continue
    unit=unit_map.get(row[11],row[11])
    if not unit:
     excluded.append({'sheet':sheet,'row':rownum,'text':name,'reason':'ข้อความเดี่ยวท้ายตาราง ไม่มีหน่วยหรือคอลัมน์สินค้า'});continue
    records.append({'sheet':sheet,'row':rownum,'category':'เครื่องดื่ม' if rownum<15 else 'บรรจุภัณฑ์และอุปกรณ์เดลิเวอรี','original_name':name,'name':name,'unit':unit,'source_max':None})

# Preserve same-name products sold in different forms as separate items.
from collections import defaultdict
names=defaultdict(list)
for r in records:names[r['name'].replace('เเ','แ')].append(r)
for name,group in names.items():
 known=[r for r in group if r['unit']]
 if len({r['unit'] for r in known})==1:
  for r in group:
   if not r['unit']:
    r['unit']=known[0]['unit'];r['category']=known[0]['category']
    r['unit_inferred_from']=f"{known[0]['sheet']} แถว {known[0]['row']} ซึ่งระบุสินค้าเดียวกันและหน่วยชัดเจน"
 if len(group)>1 and len({(r['unit'],r['category']) for r in group})>1:
  for r in group:
   r['name']=r['name']+' ('+str(r['category'] or 'ทั่วไป')+' / '+str(r['unit'] or 'รอระบุหน่วย')+')'
dedup={}
for r in records:
 key=(r['name'].replace('เเ','แ'),r['unit'])
 if key in dedup:
  dedup[key]['duplicate_sources'].append(f"{r['sheet']} แถว {r['row']}")
 else:
  r['duplicate_sources']=[]
  r['id']=str(uuid.uuid5(uuid.NAMESPACE_URL,'ruamran:legacy-siamsuki-product:'+str(key)))
  dedup[key]=r
products=list(dedup.values())
# Import standalone missing-unit products inactive; merge shopping reminders
# into their existing product sources rather than creating quantity-named items.
for note in excluded:
 if note['text']=='ผ้าถูพื้น':
  name=note['text']
  products.append({'sheet':note['sheet'],'row':note['row'],'category':'อุปกรณ์และของใช้','original_name':name,'name':name,'unit':None,'source_max':None,'duplicate_sources':[],'id':str(uuid.uuid5(uuid.NAMESPACE_URL,'ruamran:legacy-siamsuki-product:'+str((name,None))))})
 else:
  name=note['text'].rsplit(' ',1)[0]
  match=next(r for r in products if r['original_name']==name)
  match['duplicate_sources'].append(f"{note['sheet']} แถว {note['row']} ข้อความสั่งซื้อ: {note['text']}")
excluded=[]
out={'products':products,'excluded_notes':excluded,'units_normalized':unit_map}
Path('/tmp/ruamran-product-import.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'source_rows':len(records),'unique_products':len(products),'with_unit':sum(bool(r['unit']) for r in products),'missing_unit':sum(not r['unit'] for r in products),'excluded_notes':excluded,'categories':sorted({r['category'] for r in products if r['category']}),'same_name_distinctions':[r['name'] for r in products if ' / ' in r['name']]},ensure_ascii=False,indent=2))
