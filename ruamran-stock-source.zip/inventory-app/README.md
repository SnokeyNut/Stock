# รวมร้าน · Inventory Workspace

Web App ภาษาไทยสำหรับ Phase 1 ใช้ React 19 / Vinext / Shadcn UI และ Supabase Auth + PostgreSQL เป็น backend จริง ไม่มี mock stock และไม่มีการส่ง LINE

## เริ่มใช้งาน

1. เปิดเว็บ กดเข้าสู่ระบบ → สร้างบัญชี ยืนยันอีเมลหาก Supabase กำหนด แล้วล็อกอิน
2. สร้างองค์กรแรก ทุกองค์กรมีสมาชิกผู้สร้างและข้อมูลแยกจากองค์กรอื่น
3. จัดการข้อมูล → ร้าน → สาขา → ผู้ขาย → ประเภท → สินค้า
4. กำหนดผู้ขายหลัก ขั้นต่ำ เป้าหมาย และจำนวนต่อรอบสั่งสินค้า
5. ราคาและผู้ขายสินค้า → กำหนดหน่วยซื้อ ราคา และอัตราแปลงหน่วยซื้อเป็นหน่วยสต๊อก
6. เลือกร้าน/สาขา → รับเข้า เบิกออก นับจริง สร้างใบสั่งซื้อ
7. ผู้ขาย → ดูรายการสั่งซื้อวันนี้ → คัดลอกข้อความ ปรับ Template ในจัดการข้อมูล

ร้านและสาขาสามารถแยกเป็นก๋วยเตี๋ยวปลา ทิพย์เนตร / สยามสุกี้ ทิพย์เนตร / สยามสุกี้ หลัง มช. ได้ ไม่สร้างข้อมูลธุรกิจแทนผู้ใช้โดยอัตโนมัติ

## พัฒนาในเครื่อง

```sh
npm ci
npm run dev
npx tsc --noEmit
node --experimental-strip-types tests/inventory.test.mjs
npm run build
```

Backend: `pjahviamqmnfpnidydhe` ฐานข้อมูลเดิมตรวจสอบแล้วก่อนเพิ่ม migration มี 18 ตารางว่าง เปิด RLS แต่ไม่มี policies, triggers, functions หรือผู้ใช้

`lib/supabase.ts` มี URL และ **publishable key** เท่านั้น ไม่มี service-role key ข้อมูลและการเขียนถูกป้องกันที่ฐานข้อมูล ไม่ต้องใส่ secret ใน browser

## ฐานข้อมูลและสิทธิ์

- Migration แรกเพิ่ม LINE Name, organization_members, organization_settings และ transactional app_command
- Migration ถัดไปเพิ่ม snapshot อัตราแปลงหน่วยของใบสั่งซื้อ และรองรับรับบางส่วน/รับครบ
- ตาราง public ทุกตารางเปิด RLS และให้ authenticated อ่านเฉพาะสมาชิกองค์กร ไม่ให้เขียนตารางธุรกรรมตรงจาก client
- RPC public เป็น SECURITY INVOKER เรียก implementation ใน schema app_private ที่ไม่เปิด Data API พร้อม auth.uid และ membership checks ทุกคำสั่ง
- serialize การเปลี่ยน stock ต่อสาขา, ตรวจเบิกเกินยอด, ตรวจนับจากยอดเก่า, rollback ทั้งเอกสารเมื่อผิดพลาด, request UUID ป้องกัน replay คำสั่งเดิม
- ราคาการรับเป็นราคาต่อหน่วยสต๊อก ราคาผู้ขายเป็นต่อหน่วยซื้อ และเก็บราคา history แยกหน่วย
- การรับจากใบสั่งซื้อหักยอดรอรับ รองรับบางส่วนและป้องกันเกินยอด เมื่อรับครบเปลี่ยน status เป็น received
- พื้นที่ browser เก็บ session ของ Supabase; ข้อมูลธุรกิจและ Template เก็บใน PostgreSQL

## ขอบเขตและสิ่งที่ยังไม่ได้ทำ

- AI อ่านบิล/รูปเบิก, POS, Recipe/BOM, Food Cost, Usage Variance มีหน้า Coming Soon เท่านั้น
- ระบบ LINE มีเฉพาะชื่อ/ID และคัดลอกข้อความ ไม่มีการส่งออกอัตโนมัติ
- สมาชิกใหม่ยังไม่มีหน้าจอ invite/role management ผู้สร้างองค์กรเป็นสมาชิกเริ่มต้น
- สต๊อกขั้นต่ำ/เป้าหมายกำหนดระดับสินค้า ใช้ร่วมกันในทุกสาขา ยอดจริงแยกสาขา
- ไม่ใช่ระบบ lot, expiration, returns, accounting หรือ costing FIFO; มูลค่ารายงานเป็นประมาณการจากราคาล่าสุด สินค้าไม่มีราคาจะแจ้งและไม่รวม
- ทุก page อยู่ใน workspace route เดียว ใช้ hash navigation เพื่อรักษาหน้าปัจจุบัน
- SQL integration tests ใช้ fixtures ภายใน transaction และ rollback เสมอ ไม่เหลือข้อมูลทดสอบใน production

## ทดสอบฐานข้อมูล

`supabase/tests/phase1_workflows.sql` ทดสอบภายใต้ role authenticated: รับ/เบิก/นับ, insufficient stock rollback, stale count, idempotency, PO partial/full receipt, cross organization read/write/reference denial และ direct stock write denial พร้อม rollback fixtures

ให้รัน SQL ผ่าน connection ที่มีสิทธิ์สร้าง auth fixtures เช่น Supabase SQL Editor หรือ MCP execute_sql ห้ามรันผ่าน browser publishable key

Supabase Auth provider email confirmation และ redirect URL ต้องกำหนดให้เหมาะกับ production domain ใน Dashboard หาก email confirmation เปิดอยู่ ผู้ใช้ต้องยืนยันอีเมลก่อนเข้าสู่ระบบ

## GitHub Pages (siamsukicnx/Stock)

คำขอปัจจุบันใช้ GitHub Pages แทน Sites ตัวเว็บใช้ Supabase เดิม ไม่มี server หรือ service-role key บน GitHub

```sh
npm ci
npm run build:pages
```

ผลลัพธ์ `pages-dist/index.html` รวม JavaScript, CSS และ favicon ในไฟล์เดียว ไม่อ้างอิง asset ภายนอกที่ต้องตั้ง base path อัปโหลดแทน `index.html` ใน root ของ branch main ของ `siamsukicnx/Stock` โดยคง Pages source เดิม หน้าเมนูใช้ hash จึงรองรับ URL `/Stock/#dashboard` โดยไม่ต้อง server rewrite

GitHub จะเก็บ index.html เวอร์ชันเดิมใน commit history และมีสำเนาก่อนเผยแพร่ใน deployment-backup เว็บเดิมใช้ Supabase project cgpmhpmrokhpnuqfqmxp ส่วนเว็บใหม่ใช้ Phase 1 project pjahviamqmnfpnidydhe ไม่แก้ไขหรือลบ project เดิม และยังไม่ได้ย้ายข้อมูลเก่าเข้าสู่ Phase 1 โดยอัตโนมัติ

ตัวเว็บใหม่ยังไม่มีข้อมูลธุรกิจเริ่มต้น การเปลี่ยนไฟล์ HTML ไม่ลบฐานข้อมูล Supabase ให้สร้างบัญชีและเพิ่มองค์กรตามคู่มือด้านบน ตั้งค่า Supabase Auth Site URL ให้เป็น `https://siamsukicnx.github.io/Stock/` และ redirect allowlist ให้ตรงกับเว็บจริงสำหรับขั้นตอนยืนยันอีเมล
