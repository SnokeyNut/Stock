// This app uses the existing Supabase PostgreSQL database. No D1 schema.
export {};
