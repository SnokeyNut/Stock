import type { Database, Json } from "./database.types";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
// Publishable browser key only. Authorization is enforced by database RLS/RPC.
const browserCache = typeof window === "undefined" ? undefined : window as Window & { ruamranClient?: SupabaseClient<Database> };
const makeClient = () => createClient<Database>(
  "https://pjahviamqmnfpnidydhe.supabase.co",
  "sb_publishable_H-CVMRzzXhUkJkq0zJWfSQ_aXJSwEy3",
  { auth: { autoRefreshToken: typeof window !== "undefined", persistSession: typeof window !== "undefined" } },
);
export const supabase = browserCache?.ruamranClient ?? makeClient();
if (browserCache) browserCache.ruamranClient = supabase;
export async function command(
  action: string,
  payload: Record<string, unknown>,
  requestId = crypto.randomUUID(),
) {
  const { data, error } = await supabase.rpc("app_command", {
    action,
    payload: payload as Json,
    request_id: requestId,
  });
  if (error) throw new Error(error.message);
  return data;
}
