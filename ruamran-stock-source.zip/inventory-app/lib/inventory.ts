export type Row = { id: string; [key: string]: any };
export const TABLES = [
  "organizations",
  "stores",
  "branches",
  "suppliers",
  "categories",
  "products",
  "supplier_products",
  "branch_stock",
  "stock_movements",
  "stock_counts",
  "stock_count_items",
  "purchase_orders",
  "purchase_order_items",
  "goods_receipts",
  "goods_receipt_items",
  "issue_records",
  "issue_record_items",
  "price_history",
  "organization_settings",
  "organization_members",
] as const;
export type Data = Record<(typeof TABLES)[number], Row[]>;
export const emptyData = (): Data =>
  Object.fromEntries(TABLES.map((t) => [t, []])) as unknown as Data;
export const today = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Bangkok",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
export const number = (v: number) =>
  new Intl.NumberFormat("th-TH", { maximumFractionDigits: 2 }).format(v);
export const dateLabel = (d: string) =>
  new Intl.DateTimeFormat("th-TH", {
    timeZone: "Asia/Bangkok",
    dateStyle: "medium",
  }).format(new Date(d.length === 10 ? d + "T12:00:00+07:00" : d));
export function suggestion(
  quantity: number,
  min: number,
  target: number | null,
  multiple: number | null,
  conversion = 1,
) {
  if (
    quantity > min ||
    target === null ||
    target <= quantity ||
    conversion <= 0
  )
    return 0;
  const pack = multiple && multiple > 0 ? multiple : 1;
  return Math.ceil((target - quantity) / conversion / pack) * pack;
}
export function renderTemplate(
  template: string,
  values: Record<string, string>,
) {
  return template.replace(
    /\{(store|date|branch|supplier|items)\}/g,
    (_, key) => values[key] ?? "",
  );
}
