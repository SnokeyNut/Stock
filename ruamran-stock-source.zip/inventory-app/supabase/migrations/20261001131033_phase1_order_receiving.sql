alter table public.purchase_order_items add column conversion_to_stock_unit numeric not null default 1 check (conversion_to_stock_unit>0);
create policy internal_request_read on app_private.requests for select to authenticated using(user_id=(select auth.uid()));
create or replace function app_private.command(action text,payload jsonb,request_id uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); o uuid; b uuid; entity text; rec jsonb; rid uuid; old_o uuid; result jsonb; item jsonb; p public.products; sp public.supplier_products; q numeric; expected numeric; current_q numeric; cost numeric; kind text; doc uuid; count_id uuid; supplier uuid; columns_sql text; values_sql text; updates_sql text; k text; allowed text[]; qty numeric; org_name text; po_id uuid; po public.purchase_orders; poi public.purchase_order_items; already_received numeric;
begin
if u is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'กรุณาเข้าสู่ระบบด้วยบัญชีผู้ใช้'; end if;
if request_id is null then raise exception 'request_id required';end if;
perform pg_advisory_xact_lock(hashtextextended(u::text||request_id::text,0));
select r.result into result from app_private.requests r where r.user_id=u and r.request_id=command.request_id;
if found then return result;end if;
if action='create_organization' then
org_name:=trim(payload->>'name');if org_name is null or length(org_name)<2 then raise exception 'กรุณาระบุชื่อองค์กร';end if;
insert into public.organizations(name) values(org_name) returning id into o;
insert into public.organization_members values(o,u);insert into public.organization_settings(organization_id) values(o);result:=jsonb_build_object('id',o);
else
 o:=(payload->>'organization_id')::uuid;
 if not app_private.member(o) then raise exception 'ไม่มีสิทธิ์เข้าถึงองค์กรนี้';end if;
 if action='save_entity' then
 entity:=payload->>'entity';rec:=payload->'record';rid:=coalesce(nullif(rec->>'id','')::uuid,gen_random_uuid());
 allowed:=case entity when 'stores' then array['name','code','active'] when 'branches' then array['store_id','name','code','active'] when 'suppliers' then array['name','code','contact_name','line_name','line_id','notes','active'] when 'categories' then array['name','code','active'] when 'products' then array['name','code','unit','category_id','supplier_id','min_stock','target_stock','reorder_multiple','notes','active'] else null end;
 if allowed is null then raise exception 'Unsupported entity';end if;
 if length(trim(coalesce(rec->>'name','')))=0 then raise exception 'กรุณาระบุชื่อ';end if;
 execute format('select %s from public.%I where id=$1 for update',case when entity='branches' then 'app_private.branch_org(id)' else 'organization_id' end,entity) into old_o using rid;
 if old_o is not null and old_o<>o then raise exception 'ไม่มีสิทธิ์แก้ไขข้อมูลนี้';end if;
 if entity='branches' and not exists(select 1 from public.stores where id=(rec->>'store_id')::uuid and organization_id=o) then raise exception 'ร้านไม่อยู่ในองค์กรนี้';end if;
 if entity='products' then
 if coalesce(rec->>'unit','')='' or (rec->>'min_stock')::numeric<0 or (rec->>'target_stock')::numeric<0 or (rec->>'reorder_multiple')::numeric<=0 then raise exception 'หน่วยหรือระดับสต๊อกไม่ถูกต้อง';end if;
 if nullif(rec->>'category_id','') is not null and not exists(select 1 from public.categories where id=(rec->>'category_id')::uuid and organization_id=o) then raise exception 'ประเภทไม่อยู่ในองค์กรนี้';end if;
 if nullif(rec->>'supplier_id','') is not null and not exists(select 1 from public.suppliers where id=(rec->>'supplier_id')::uuid and organization_id=o) then raise exception 'ผู้ขายไม่อยู่ในองค์กรนี้';end if;
 end if;
 columns_sql:='id';values_sql:=quote_literal(rid);updates_sql:='';
 if entity<>'branches' then columns_sql:=columns_sql||',organization_id';values_sql:=values_sql||','||quote_literal(o);end if;
 foreach k in array allowed loop if rec ? k then columns_sql:=columns_sql||','||quote_ident(k);values_sql:=values_sql||','||coalesce(quote_literal(nullif(rec->>k,'')),'NULL');updates_sql:=updates_sql||case when updates_sql='' then '' else ',' end||format('%I=excluded.%I',k,k);end if;end loop;
 execute format('insert into public.%I (%s) values (%s) on conflict(id) do update set %s returning id',entity,columns_sql,values_sql,updates_sql) into rid;
 result:=jsonb_build_object('id',rid);
 elsif action='save_template' then
 if length(coalesce(payload->>'template',''))=0 or length(payload->>'template')>10000 then raise exception 'Template ไม่ถูกต้อง';end if;
 insert into public.organization_settings(organization_id,order_template) values(o,payload->>'template') on conflict(organization_id) do update set order_template=excluded.order_template; result:='{"saved":true}';
 elsif action='save_price' then
 select * into p from public.products where id=(payload->>'product_id')::uuid and organization_id=o and active;
 if not found then raise exception 'ไม่พบสินค้า';end if;
 supplier:=(payload->>'supplier_id')::uuid;
 if not exists(select 1 from public.suppliers where id=supplier and organization_id=o and active) then raise exception 'ไม่พบผู้ขาย';end if;
 cost:=(payload->>'price')::numeric;qty:=coalesce((payload->>'conversion')::numeric,1);
 if cost is null or cost<0 or qty is null or qty<=0 or coalesce(payload->>'unit','')='' then raise exception 'ราคา หน่วย หรืออัตราแปลงไม่ถูกต้อง';end if;
 insert into public.supplier_products(supplier_id,product_id,last_price,purchase_unit,conversion_to_stock_unit,is_preferred) values(supplier,p.id,cost,payload->>'unit',qty,true) on conflict(supplier_id,product_id) do update set last_price=excluded.last_price,purchase_unit=excluded.purchase_unit,conversion_to_stock_unit=excluded.conversion_to_stock_unit;
 insert into public.price_history(product_id,supplier_id,price,unit,effective_date) values(p.id,supplier,cost,payload->>'unit',coalesce((payload->>'date')::date,(now() at time zone 'Asia/Bangkok')::date));result:='{"saved":true}';
 elsif action in ('receive','issue','count','create_order','set_order_status') then
 b:=(payload->>'branch_id')::uuid;
 if app_private.branch_org(b) is distinct from o or not exists(select 1 from public.branches where id=b and active) then raise exception 'สาขาไม่อยู่ในองค์กรนี้หรือปิดใช้งาน';end if;
 perform pg_advisory_xact_lock(hashtextextended(b::text,0));
 if action='set_order_status' then
 if payload->>'status' not in ('ordered','cancelled') then raise exception 'สถานะไม่ถูกต้อง';end if;
 update public.purchase_orders set status=payload->>'status' where id=(payload->>'id')::uuid and branch_id=b and status in ('draft','ordered') returning id into doc;
 if doc is null then raise exception 'ไม่พบใบสั่งซื้อหรือสถานะไม่อนุญาต';end if;result:=jsonb_build_object('id',doc);
 else
 if jsonb_typeof(payload->'items') is distinct from 'array' or jsonb_array_length(payload->'items')=0 then raise exception 'กรุณาเพิ่มรายการสินค้า';end if;
 if (select count(*) from jsonb_array_elements(payload->'items'))<>(select count(distinct x->>'product_id') from jsonb_array_elements(payload->'items') x) then raise exception 'สินค้าซ้ำในเอกสาร';end if;
 supplier:=nullif(payload->>'supplier_id','')::uuid;
 if supplier is not null and not exists(select 1 from public.suppliers where id=supplier and organization_id=o and active) then raise exception 'ผู้ขายไม่อยู่ในองค์กรนี้';end if;
 if action='create_order' and supplier is null then raise exception 'กรุณาเลือกผู้ขาย';end if;
 po_id:=nullif(payload->>'purchase_order_id','')::uuid;
 if action='receive' and po_id is not null then
 select * into po from public.purchase_orders where id=po_id and branch_id=b and supplier_id=supplier and status='ordered' for update;
 if not found then raise exception 'ไม่พบใบสั่งซื้อที่รอรับของสาขาและผู้ขายนี้';end if;
 end if;
 if action='receive' then insert into public.goods_receipts(branch_id,supplier_id,purchase_order_id,receipt_date,document_number,notes) values(b,supplier,po_id,coalesce((payload->>'date')::date,(now() at time zone 'Asia/Bangkok')::date),payload->>'document_number',payload->>'note') returning id into doc;
 elsif action='issue' then insert into public.issue_records(branch_id,issue_date,note) values(b,coalesce((payload->>'date')::date,(now() at time zone 'Asia/Bangkok')::date),payload->>'note') returning id into doc;
 elsif action='count' then insert into public.stock_counts(branch_id,count_date,status,note) values(b,coalesce((payload->>'date')::date,(now() at time zone 'Asia/Bangkok')::date),'completed',payload->>'note') returning id into doc;
 else insert into public.purchase_orders(branch_id,supplier_id,order_date,status,notes) values(b,supplier,coalesce((payload->>'date')::date,(now() at time zone 'Asia/Bangkok')::date),'draft',payload->>'note') returning id into doc;end if;
 for item in select * from jsonb_array_elements(payload->'items') loop
 select * into p from public.products where id=(item->>'product_id')::uuid and organization_id=o and active;
 if not found then raise exception 'สินค้าไม่อยู่ในองค์กรนี้หรือปิดใช้งาน';end if;
 q:=(item->>'quantity')::numeric;cost:=nullif(item->>'unit_price','')::numeric;
 if q is null or q<0 or q>1000000000 or (action<>'count' and q=0) or (cost is not null and cost<0) then raise exception 'จำนวนหรือราคาไม่ถูกต้อง';end if;
 if action='create_order' then
 select * into sp from public.supplier_products where supplier_id=supplier and product_id=p.id;
 if not found and p.supplier_id is distinct from supplier then raise exception 'สินค้ายังไม่ได้ผูกกับผู้ขายนี้';end if;
 if nullif(item->>'unit','') is null then raise exception 'กรุณาระบุหน่วย';end if;
 if item->>'unit' is distinct from coalesce(sp.purchase_unit,p.unit) then raise exception 'หน่วยซื้อไม่ตรงกับข้อมูลผู้ขาย';end if;
 insert into public.purchase_order_items(purchase_order_id,product_id,suggested_quantity,ordered_quantity,unit_price,unit,conversion_to_stock_unit) values(doc,p.id,coalesce((item->>'suggested_quantity')::numeric,q),q,cost,item->>'unit',coalesce(sp.conversion_to_stock_unit,1));
 else
 insert into public.branch_stock(branch_id,product_id,quantity) values(b,p.id,0) on conflict(branch_id,product_id) do nothing;
 select quantity into current_q from public.branch_stock where branch_id=b and product_id=p.id for update;
 if action='issue' and current_q<q then raise exception 'สต๊อก % ไม่เพียงพอ',p.name;end if;
 if action='count' then expected:=(item->>'expected_quantity')::numeric;if expected is null or current_q<>expected then raise exception 'ยอด % เปลี่ยนระหว่างนับ กรุณาโหลดใหม่',p.name;end if;end if;
 if action='receive' then
 if po_id is not null then
 select * into poi from public.purchase_order_items where purchase_order_id=po_id and product_id=p.id;
 if not found then raise exception 'สินค้าไม่ได้อยู่ในใบสั่งซื้อนี้';end if;
 select coalesce(sum(i.quantity),0) into already_received from public.goods_receipt_items i join public.goods_receipts r on r.id=i.goods_receipt_id where r.purchase_order_id=po_id and i.product_id=p.id;
 if q+already_received>poi.ordered_quantity*poi.conversion_to_stock_unit then raise exception 'จำนวนรับเกินยอดที่สั่ง';end if;
 end if;
 insert into public.goods_receipt_items(goods_receipt_id,product_id,quantity,unit,unit_price,total_price) values(doc,p.id,q,p.unit,cost,q*cost);
 if supplier is not null and cost is not null then
 insert into public.price_history(product_id,supplier_id,price,unit,effective_date) values(p.id,supplier,cost,p.unit,coalesce((payload->>'date')::date,(now() at time zone 'Asia/Bangkok')::date));
 -- Preserve purchase-unit conversion; receiving price is per stock unit.
 update public.supplier_products set last_price=cost*conversion_to_stock_unit where supplier_id=supplier and product_id=p.id;
 end if;
 elsif action='issue' then insert into public.issue_record_items(issue_record_id,product_id,quantity,unit,note) values(doc,p.id,q,p.unit,payload->>'note');
 else insert into public.stock_count_items(stock_count_id,product_id,system_quantity,actual_quantity) values(doc,p.id,current_q,q);end if;
 qty:=case action when 'receive' then q when 'issue' then -q else q-current_q end;
 update public.branch_stock set quantity=current_q+qty,updated_at=now(),last_counted_at=case when action='count' then now() else last_counted_at end where branch_id=b and product_id=p.id;
 insert into public.stock_movements(branch_id,product_id,movement_type,quantity,unit_cost,reference_type,reference_id,note) values(b,p.id,action,qty,cost,case action when 'receive' then 'goods_receipt' when 'issue' then 'issue_record' else 'stock_count' end,doc,payload->>'note');
 end if;
 end loop;
 if action='receive' and po_id is not null and not exists(select 1 from public.purchase_order_items i where i.purchase_order_id=po_id and i.ordered_quantity*i.conversion_to_stock_unit>(select coalesce(sum(gi.quantity),0) from public.goods_receipt_items gi join public.goods_receipts gr on gr.id=gi.goods_receipt_id where gr.purchase_order_id=po_id and gi.product_id=i.product_id)) then update public.purchase_orders set status='received' where id=po_id;end if;
 result:=jsonb_build_object('id',doc);
 end if;
 else raise exception 'Unsupported action';end if;
end if;
insert into app_private.requests values(u,request_id,result);return result;
end $$;
