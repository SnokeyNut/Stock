-- Roles are stored in the database, never in editable auth user metadata.
alter table public.organization_members add column role text not null default 'operator'
  check(role in ('admin','operator','viewer'));
alter table public.organization_members add column active boolean not null default true;

-- This deployment has exactly one verified user and one membership in รวมร้าน.
-- Fail closed rather than guessing an administrator when restoring into another DB.
do $$ begin
if exists(select 1 from public.organization_members) then
 if (select count(*) from public.organization_members)<>1
 or (select count(*) from auth.users)<>1
 or not exists(select 1 from public.organization_members m
   join public.organizations o on o.id=m.organization_id
   join auth.users u on u.id=m.user_id
   where o.name='รวมร้าน' and u.email_confirmed_at is not null) then
  raise exception 'Administrator bootstrap requires the audited sole verified member in รวมร้าน';
 end if;
 update public.organization_members set role='admin';
end if;
end $$;

create or replace function app_private.member(o uuid) returns boolean
language sql stable security definer set search_path='' as $$
select auth.uid() is not null and exists(select 1 from public.organization_members
where organization_id=o and user_id=auth.uid() and active)
$$;
create function app_private.current_role(o uuid) returns text
language sql stable security definer set search_path='' as $$
select role from public.organization_members where organization_id=o and user_id=auth.uid() and active
$$;
revoke all on function app_private.current_role(uuid) from public,anon;
grant execute on function app_private.current_role(uuid) to authenticated;

-- Keep the tested transactional stock workflows behind the new authorization layer.
alter function app_private.command(text,jsonb,uuid) rename to command_workflows;
do $$ declare definition text; begin
definition:=pg_get_functiondef('app_private.command_workflows(text,jsonb,uuid)'::regprocedure);
if strpos(definition,'r.request_id=command.request_id')=0
or strpos(definition,'insert into public.organization_members values(o,u)')=0 then
 raise exception 'Workflow source changed; inspect before migration'; end if;
definition:=replace(definition,'r.request_id=command.request_id','r.request_id=$3');
definition:=replace(definition,'insert into public.organization_members values(o,u)',
 'insert into public.organization_members(organization_id,user_id,role) values(o,u,''admin'')');
execute definition;
end $$;
revoke all on function app_private.command_workflows(text,jsonb,uuid) from public,anon,authenticated;

create function app_private.command(action text,payload jsonb,request_id uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); o uuid; actor_role text; target uuid; target_role text;
target_active boolean; result jsonb;
begin
if u is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then
 raise exception 'กรุณาเข้าสู่ระบบด้วยบัญชีผู้ใช้'; end if;
if request_id is null then raise exception 'request_id required'; end if;
if action='create_organization' then
 return app_private.command_workflows(action,payload,request_id);
end if;
o:=(payload->>'organization_id')::uuid;
-- Serialize role changes with writes, so revocation cannot race an in-flight command.
perform pg_advisory_xact_lock(hashtextextended('org-role:'||o::text,0));
actor_role:=app_private.current_role(o);
if actor_role is null then raise exception 'ไม่มีสิทธิ์เข้าถึงองค์กรนี้'; end if;
if action in ('list_members','add_member','set_member_role') then
 if actor_role<>'admin' then raise exception 'เฉพาะแอดมินเท่านั้นที่จัดการผู้ใช้ได้'; end if;
 if action='list_members' then
  select coalesce(jsonb_agg(jsonb_build_object('user_id',m.user_id,'email',a.email,
    'role',m.role,'active',m.active) order by a.email),'[]'::jsonb) into result
  from public.organization_members m join auth.users a on a.id=m.user_id where m.organization_id=o;
  return result;
 end if;
 perform pg_advisory_xact_lock(hashtextextended(u::text||request_id::text,0));
 select r.result into result from app_private.requests r where r.user_id=u and r.request_id=$3;
 if found then return result; end if;
 target_role:=payload->>'role';
 if target_role is null or target_role not in ('admin','operator','viewer') then raise exception 'สิทธิ์ไม่ถูกต้อง'; end if;
 if action='add_member' then
  select id into target from auth.users where lower(email)=lower(trim(payload->>'email'))
    and email_confirmed_at is not null and not coalesce(is_anonymous,false);
  if target is null then raise exception 'ไม่สามารถเพิ่มบัญชีนี้ได้ กรุณาตรวจอีเมลและให้ผู้ใช้ยืนยันบัญชีก่อน'; end if;
  if exists(select 1 from public.organization_members where organization_id=o and user_id=target) then
    raise exception 'บัญชีนี้เป็นสมาชิกแล้ว กรุณาปรับสิทธิ์ในรายการ'; end if;
  insert into public.organization_members(organization_id,user_id,role) values(o,target,target_role);
 else
  target:=(payload->>'user_id')::uuid;
  if target=u then raise exception 'ไม่สามารถลดหรือเปลี่ยนสิทธิ์บัญชีของตัวเองได้'; end if;
  target_active:=(payload->>'active')::boolean;
  if target_active is null then raise exception 'กรุณาระบุสถานะสมาชิก'; end if;
  update public.organization_members set role=target_role,active=target_active where organization_id=o and user_id=target;
  if not found then raise exception 'ไม่พบสมาชิกในองค์กรนี้'; end if;
 end if;
 result:='{"saved":true}'::jsonb;
 insert into app_private.requests values(u,request_id,result);
 return result;
end if;
if actor_role='viewer' then raise exception 'บัญชีนี้มีสิทธิ์ดูข้อมูลเท่านั้น'; end if;
if action in ('save_entity','save_price','save_template') and actor_role<>'admin' then
 raise exception 'เฉพาะแอดมินเท่านั้นที่จัดการข้อมูลพื้นฐานและการตั้งค่าได้'; end if;
return app_private.command_workflows(action,payload,request_id);
end $$;
revoke all on function app_private.command(text,jsonb,uuid) from public,anon;
grant execute on function app_private.command(text,jsonb,uuid) to authenticated;
create or replace function public.app_command(action text,payload jsonb,request_id uuid)
returns jsonb language sql security invoker set search_path='' as $$
select app_private.command(action,payload,request_id)
$$;
