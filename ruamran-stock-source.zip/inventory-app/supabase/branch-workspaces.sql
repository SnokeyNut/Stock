-- Branch master data and explicit user scopes. No deletion of business records.
alter table public.organization_members drop constraint organization_members_role_check;
alter table public.organization_members add constraint organization_members_role_check check(role in ('admin','store_manager','branch_manager','staff','operator','viewer'));
create table public.member_scopes (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id),
 user_id uuid not null references auth.users(id),
 store_id uuid references public.stores(id),
 branch_id uuid references public.branches(id),
 foreign key(organization_id,user_id) references public.organization_members(organization_id,user_id),
 check ((store_id is null) <> (branch_id is null))
);
create index member_scopes_user_org on public.member_scopes(user_id,organization_id);
create unique index member_scopes_store_unique on public.member_scopes(organization_id,user_id,store_id) where store_id is not null;
create unique index member_scopes_branch_unique on public.member_scopes(organization_id,user_id,branch_id) where branch_id is not null;
alter table public.member_scopes enable row level security;
revoke all on public.member_scopes from anon,authenticated;
grant select on public.member_scopes to authenticated;
create policy scope_read on public.member_scopes for select to authenticated using(user_id=(select auth.uid()) or app_private.current_role(organization_id)='admin');

alter table public.products add column branch_id uuid references public.branches(id);
alter table public.suppliers add column branch_id uuid references public.branches(id);
alter table public.categories add column branch_id uuid references public.branches(id);
-- Select the audited destination by its business names, and fail closed on ambiguity.
do $$ declare destination uuid; org uuid; begin
 select b.id,s.organization_id into destination,org from public.branches b join public.stores s on s.id=b.store_id join public.organizations o on o.id=s.organization_id where o.name='รวมร้าน' and s.name='สยามสุกี้' and b.name='ทิพย์เนตร';
 if (select count(*) from public.branches b join public.stores s on s.id=b.store_id join public.organizations o on o.id=s.organization_id where o.name='รวมร้าน' and s.name='สยามสุกี้' and b.name='ทิพย์เนตร')<>1 then raise exception 'Ambiguous import destination';end if;
 if (select count(*) from public.products where organization_id=org)<>184 or exists(select 1 from public.stock_movements) then raise exception 'Imported data changed; inspect before moving';end if;
 update public.products set branch_id=destination where organization_id=org;
 update public.categories set branch_id=destination where organization_id=org;
 update public.suppliers set branch_id=destination where organization_id=org;
end $$;
alter table public.products alter column branch_id set not null;
alter table public.suppliers alter column branch_id set not null;
alter table public.categories alter column branch_id set not null;
create index products_branch on public.products(branch_id);
create index suppliers_branch on public.suppliers(branch_id);
create index categories_branch on public.categories(branch_id);
create table public.branch_settings (
 branch_id uuid primary key references public.branches(id),
 order_template text not null default E'ร้าน: {store}\nวันที่: {date}\nสาขา: {branch}\nผู้ขาย: {supplier}\n\n{items}'
);
insert into public.branch_settings(branch_id,order_template) select b.id,os.order_template from public.branches b join public.stores s on s.id=b.store_id join public.organization_settings os on os.organization_id=s.organization_id;
alter table public.branch_settings enable row level security;
revoke all on public.branch_settings from anon,authenticated;
grant select on public.branch_settings to authenticated;

create function app_private.branch_access(b uuid, financial boolean default false) returns boolean language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists (
 select 1 from public.branches br join public.stores s on s.id=br.store_id join public.organization_members m on m.organization_id=s.organization_id and m.user_id=auth.uid() and m.active
 where br.id=b and (not financial or m.role in ('admin','store_manager','branch_manager')) and (
 m.role='admin' or exists(select 1 from public.member_scopes ms where ms.organization_id=m.organization_id and ms.user_id=m.user_id and (
 (m.role='store_manager' and ms.store_id=s.id) or (m.role in ('branch_manager','staff','operator','viewer') and ms.branch_id=br.id)))))
$$;
revoke all on function app_private.branch_access(uuid,boolean) from public,anon;
grant execute on function app_private.branch_access(uuid,boolean) to authenticated;
create policy branch_settings_read on public.branch_settings for select to authenticated using(app_private.branch_access(branch_id));
-- Replace organization-wide policies; descendant item policies inherit parent RLS.
drop policy member_read on public.stores;
create policy member_read on public.stores for select to authenticated using(app_private.current_role(organization_id)='admin' or exists(select 1 from public.branches b where b.store_id=stores.id and app_private.branch_access(b.id)));
drop policy member_read on public.branches;
create policy member_read on public.branches for select to authenticated using(app_private.branch_access(id));
do $$ declare t text; begin
 foreach t in array array['products','suppliers','categories','branch_stock','stock_movements','stock_counts','purchase_orders','goods_receipts','issue_records'] loop
 execute format('drop policy member_read on public.%I',t);
 execute format('create policy member_read on public.%I for select to authenticated using(app_private.branch_access(branch_id))',t);
 end loop;
end $$;
drop policy member_read on public.organization_members;
create policy member_read on public.organization_members for select to authenticated using(user_id=(select auth.uid()) or app_private.current_role(organization_id)='admin');
drop policy member_read on public.organization_settings;
create policy member_read on public.organization_settings for select to authenticated using(app_private.current_role(organization_id)='admin');
drop policy member_read on public.supplier_products;
create policy member_read on public.supplier_products for select to authenticated using(exists(select 1 from public.products p where p.id=product_id and app_private.branch_access(p.branch_id,true)));
drop policy member_read on public.price_history;
create policy member_read on public.price_history for select to authenticated using(exists(select 1 from public.products p where p.id=product_id and app_private.branch_access(p.branch_id,true)));

-- Guard transactional foreign keys even for privileged workflow code.
create function app_private.check_branch_links() returns trigger language plpgsql set search_path='' as $$
declare pb uuid; sb uuid; cb uuid; ob uuid; begin
 if tg_table_name in ('products','suppliers','categories') then
  if app_private.branch_org(new.branch_id) is distinct from new.organization_id then raise exception 'Branch organization mismatch';end if;
  if tg_op='UPDATE' and (new.branch_id<>old.branch_id or new.organization_id<>old.organization_id) then raise exception 'Cannot move an existing master record between branches';end if;
  if tg_table_name='products' then
   if new.category_id is not null and not exists(select 1 from public.categories where id=new.category_id and branch_id=new.branch_id) then raise exception 'Category belongs to another branch';end if;
   if new.supplier_id is not null and not exists(select 1 from public.suppliers where id=new.supplier_id and branch_id=new.branch_id) then raise exception 'Supplier belongs to another branch';end if;
  end if;
 elsif tg_table_name in ('supplier_products','price_history') then
  select branch_id into pb from public.products where id=new.product_id;
  select branch_id into sb from public.suppliers where id=new.supplier_id;
  if new.supplier_id is not null and pb is distinct from sb then raise exception 'Price supplier belongs to another branch';end if;
 elsif tg_table_name in ('purchase_orders','goods_receipts') then
  if new.supplier_id is not null and not exists(select 1 from public.suppliers where id=new.supplier_id and branch_id=new.branch_id) then raise exception 'Document supplier belongs to another branch';end if;
 elsif tg_table_name='branch_stock' or tg_table_name='stock_movements' then
  if not exists(select 1 from public.products where id=new.product_id and branch_id=new.branch_id) then raise exception 'Stock product belongs to another branch';end if;
 end if;
 return new;
end $$;
revoke all on function app_private.check_branch_links() from public,anon,authenticated;
do $$ declare t text; begin
 foreach t in array array['products','suppliers','categories','supplier_products','price_history','purchase_orders','goods_receipts','branch_stock','stock_movements'] loop
 execute format('create trigger check_branch_links before insert or update on public.%I for each row execute function app_private.check_branch_links()',t);
 end loop;
end $$;
-- Teach existing, tested master CRUD about the branch column.
do $$ declare definition text; begin
 definition:=pg_get_functiondef('app_private.command_workflows(text,jsonb,uuid)'::regprocedure);
 if strpos(definition,$needle$array['name','code','contact_name'$needle$)=0 then raise exception 'Workflow source changed';end if;
 definition:=replace(definition,$needle$when 'suppliers' then array['name'$needle$,$needle$when 'suppliers' then array['branch_id','name'$needle$);
 definition:=replace(definition,$needle$when 'categories' then array['name'$needle$,$needle$when 'categories' then array['branch_id','name'$needle$);
 definition:=replace(definition,$needle$when 'products' then array['name'$needle$,$needle$when 'products' then array['branch_id','name'$needle$);
 execute definition;
end $$;
create or replace function app_private.command(action text,payload jsonb,request_id uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); o uuid; b uuid; actor_role text; target uuid; target_role text; target_active boolean; result jsonb; rec jsonb; item jsonb; ent text; sid uuid; scope jsonb; old_branch uuid;
begin
 if u is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'กรุณาเข้าสู่ระบบ';end if;
 if request_id is null then raise exception 'request_id required';end if;
 if action='create_organization' then return app_private.command_workflows(action,payload,request_id);end if;
 o:=(payload->>'organization_id')::uuid;
 perform pg_advisory_xact_lock(hashtextextended('org-role:'||o::text,0));
 actor_role:=app_private.current_role(o);
 if actor_role is null then raise exception 'ไม่มีสิทธิ์เข้าถึงองค์กรนี้';end if;
 if action in ('list_members','add_member','set_member_role') then
  if actor_role<>'admin' then raise exception 'เฉพาะแอดมินจัดการผู้ใช้ได้';end if;
  if action='list_members' then
   select coalesce(jsonb_agg(jsonb_build_object('user_id',m.user_id,'email',a.email,'role',m.role,'active',m.active,'scopes',(select coalesce(jsonb_agg(jsonb_build_object('store_id',ms.store_id,'branch_id',ms.branch_id)),'[]') from public.member_scopes ms where ms.organization_id=o and ms.user_id=m.user_id)) order by a.email),'[]') into result from public.organization_members m join auth.users a on a.id=m.user_id where m.organization_id=o;
   return result;
  end if;
  perform pg_advisory_xact_lock(hashtextextended(u::text||request_id::text,0));
  select r.result into result from app_private.requests r where r.user_id=u and r.request_id=$3;
  if found then return result;end if;
  target_role:=payload->>'role';
  if target_role is null or target_role not in ('admin','store_manager','branch_manager','staff','operator','viewer') then raise exception 'สิทธิ์ไม่ถูกต้อง';end if;
  if jsonb_typeof(payload->'scopes') is distinct from 'array' then raise exception 'กรุณาระบุพื้นที่เข้าถึง';end if;
  if action='add_member' then
   select id into target from auth.users where lower(email)=lower(trim(payload->>'email')) and email_confirmed_at is not null and not coalesce(is_anonymous,false);
   if target is null then raise exception 'ผู้ใช้ต้องสมัครและยืนยันอีเมลก่อน';end if;
   if exists(select 1 from public.organization_members where organization_id=o and user_id=target) then raise exception 'ผู้ใช้เป็นสมาชิกแล้ว';end if;
   insert into public.organization_members(organization_id,user_id,role) values(o,target,target_role);
  else
   target:=(payload->>'user_id')::uuid;
   if target=u then raise exception 'ไม่สามารถเปลี่ยนสิทธิ์ตัวเองได้';end if;
   target_active:=(payload->>'active')::boolean;
   if target_active is null then raise exception 'กรุณาระบุสถานะ';end if;
   update public.organization_members set role=target_role,active=target_active where organization_id=o and user_id=target;
   if not found then raise exception 'ไม่พบสมาชิก';end if;
  end if;
  if target_role<>'admin' and jsonb_array_length(payload->'scopes')=0 then raise exception 'เลือกอย่างน้อยหนึ่งร้านหรือสาขา';end if;
  delete from public.member_scopes where organization_id=o and user_id=target;
  for scope in select value from jsonb_array_elements(payload->'scopes') loop
   sid:=nullif(scope->>'store_id','')::uuid;b:=nullif(scope->>'branch_id','')::uuid;
   if target_role='store_manager' then
    if b is not null or sid is null or not exists(select 1 from public.stores where id=sid and organization_id=o) then raise exception 'ขอบเขตร้านไม่ถูกต้อง';end if;
   elsif target_role<>'admin' then
    if sid is not null or b is null or app_private.branch_org(b) is distinct from o then raise exception 'ขอบเขตสาขาไม่ถูกต้อง';end if;
   else continue;end if;
   insert into public.member_scopes(organization_id,user_id,store_id,branch_id) values(o,target,sid,b);
  end loop;
  result:='{"saved":true}';insert into app_private.requests values(u,request_id,result);return result;
 end if;
 if actor_role='viewer' then raise exception 'มีสิทธิ์ดูข้อมูลเท่านั้น';end if;
 b:=nullif(payload->>'branch_id','')::uuid;
 if action='save_entity' then
  ent:=payload->>'entity';rec:=payload->'record';
  if ent in ('stores','branches') then
   if actor_role<>'admin' then raise exception 'เฉพาะแอดมินจัดการร้านและสาขาได้';end if;
   if ent='branches' and nullif(rec->>'id','') is not null and exists(select 1 from public.branches br where br.id=(rec->>'id')::uuid and br.store_id is distinct from (rec->>'store_id')::uuid) then raise exception 'ไม่สามารถย้ายสาขาไปอีกร้าน';end if;
   return app_private.command_workflows(action,payload,request_id);
  end if;
  if ent not in ('products','suppliers','categories') then raise exception 'Unsupported entity';end if;
  b:=(rec->>'branch_id')::uuid;
  if nullif(rec->>'id','') is not null then
   execute format('select branch_id from public.%I where id=$1',ent) into old_branch using (rec->>'id')::uuid;
   if old_branch is not null and old_branch is distinct from b then raise exception 'ไม่สามารถแก้หรือย้ายข้อมูลข้ามสาขา';end if;
  end if;
 end if;
 if b is null or app_private.branch_org(b) is distinct from o or not app_private.branch_access(b) then raise exception 'ไม่มีสิทธิ์เข้าถึงสาขานี้';end if;
 if action in ('save_entity','save_price','save_template') and actor_role not in ('admin','store_manager','branch_manager') then raise exception 'เฉพาะผู้จัดการหรือแอดมินจัดการข้อมูลได้';end if;
 if action='save_template' then
  if length(coalesce(payload->>'template',''))=0 or length(payload->>'template')>10000 then raise exception 'Template ไม่ถูกต้อง';end if;
  insert into public.branch_settings(branch_id,order_template) values(b,payload->>'template') on conflict(branch_id) do update set order_template=excluded.order_template;
  return '{"saved":true}';
 end if;
 if action='save_price' then
  if not exists(select 1 from public.products where id=(payload->>'product_id')::uuid and branch_id=b) or not exists(select 1 from public.suppliers where id=(payload->>'supplier_id')::uuid and branch_id=b) then raise exception 'สินค้าหรือผู้ขายอยู่คนละสาขา';end if;
 end if;
 if action in ('receive','issue','count','create_order') then
  for item in select value from jsonb_array_elements(payload->'items') loop
   if not exists(select 1 from public.products where id=(item->>'product_id')::uuid and branch_id=b) then raise exception 'สินค้าอยู่คนละสาขา';end if;
  end loop;
 end if;
 if nullif(payload->>'supplier_id','') is not null and not exists(select 1 from public.suppliers where id=(payload->>'supplier_id')::uuid and branch_id=b) then raise exception 'ผู้ขายอยู่คนละสาขา';end if;
 return app_private.command_workflows(action,payload,request_id);
end $$;
revoke all on function app_private.command(text,jsonb,uuid) from public,anon;
grant execute on function app_private.command(text,jsonb,uuid) to authenticated;
