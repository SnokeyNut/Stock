"use client";
import { useEffect, useState } from "react";
import { command } from "@/lib/supabase";
import type { Row } from "@/lib/inventory";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
export type MemberRole = "admin" | "store_manager" | "branch_manager" | "staff" | "operator" | "viewer";
export const roleLabels: Record<MemberRole,string> = {admin:"แอดมิน",store_manager:"ผู้จัดการร้าน",branch_manager:"ผู้จัดการสาขา",staff:"พนักงาน",operator:"ผู้ปฏิบัติงาน (เดิม)",viewer:"ดูข้อมูลเท่านั้น"};
type Scope = {store_id?:string|null;branch_id?:string|null};
type Member = {user_id:string;email:string;role:MemberRole;active:boolean;scopes:Scope[]};
const choices:MemberRole[]=["admin","store_manager","branch_manager","staff","viewer"];
export function MemberSettings({organizationId,userId,role,onChanged,stores,branches}:{organizationId:string;userId:string;role:MemberRole|undefined;onChanged:()=>Promise<void>;stores:Row[];branches:Row[]}) {
 const [members,setMembers]=useState<Member[]>([]),[error,setError]=useState(""),[loading,setLoading]=useState(false),[busy,setBusy]=useState(false),[version,setVersion]=useState(0);
 const [edit,setEdit]=useState<Member|null>(null),[email,setEmail]=useState(""),[selectedRole,setSelectedRole]=useState<MemberRole>("staff"),[selected,setSelected]=useState<string[]>([]),[active,setActive]=useState(true);
 useEffect(()=>{let valid=true;setMembers([]);setError("");if(role!=="admin"||!organizationId)return;setLoading(true);
  command("list_members",{organization_id:organizationId}).then(d=>{if(valid)setMembers(d as Member[]);}).catch(e=>{if(valid)setError(e.message);}).finally(()=>{if(valid)setLoading(false);});return()=>{valid=false;};
 },[organizationId,role,version]);
 const scopeOptions=selectedRole==="store_manager"?stores:branches.map(b=>({...b,name:`${stores.find(s=>s.id===b.store_id)?.name} / ${b.name}`}));
 const reset=()=>{setEdit(null);setEmail("");setSelectedRole("staff");setSelected([]);setActive(true);};
 const save=async()=>{if(busy)return;setBusy(true);setError("");
  const scopes=selectedRole==="admin"?[]:selected.map(id=>selectedRole==="store_manager"?{store_id:id}:{branch_id:id});
  try{await command(edit?"set_member_role":"add_member",{organization_id:organizationId,...(edit?{user_id:edit.user_id,active}:{email}),role:selectedRole,scopes});await onChanged();setVersion(v=>v+1);reset();toast.success("บันทึกสิทธิ์และพื้นที่เข้าถึงแล้ว");}
  catch(e){setError((e as Error).message);}finally{setBusy(false);}
 };
 return <section className="panel"><div className="panel-head"><div><h2>ผู้ใช้และพื้นที่เข้าถึง</h2><p>แอดมินเข้าถึงทุกพื้นที่ · ผู้จัดการร้านเลือกได้เฉพาะร้านที่มอบหมาย · ผู้จัดการสาขาและพนักงานเลือกได้เฉพาะสาขาที่มอบหมาย</p></div></div>
 {role!=="admin"?<p>เฉพาะแอดมินจัดการสิทธิ์ผู้ใช้ได้</p>:<>
 {error&&<p role="alert" className="note-text">{error}</p>}
 {loading?<p>กำลังโหลดสมาชิก…</p>:<div className="table-wrap"><table className="w-full text-sm"><thead><tr><th>บัญชี</th><th>บทบาท</th><th>พื้นที่เข้าถึง</th><th>สถานะ</th><th/></tr></thead><tbody>{members.map(m=><tr key={m.user_id}>
 <td className="p-3">{m.email}{m.user_id===userId&&" (คุณ)"}</td><td>{roleLabels[m.role]}</td><td>{m.role==="admin"?"ทุกร้าน / ทุกสาขา":m.scopes.map(sc=>sc.store_id?stores.find(s=>s.id===sc.store_id)?.name:scopeName(sc.branch_id,stores,branches)).join(", ")||"ยังไม่ได้มอบหมาย"}</td><td>{m.active?"เปิดใช้งาน":"ระงับสิทธิ์"}</td>
 <td><Button variant="outline" disabled={busy||m.user_id===userId} onClick={()=>{setEdit(m);setEmail(m.email);setSelectedRole(m.role);setActive(m.active);setSelected(m.scopes.map(sc=>sc.store_id||sc.branch_id||""));}}>แก้ไข</Button></td></tr>)}</tbody></table></div>}
 <form className="space-y-3 mt-4" onSubmit={e=>{e.preventDefault();void save();}}><h3>{edit?"แก้ไขสิทธิ์สมาชิก":"เพิ่มสมาชิกที่มีบัญชีแล้ว"}</h3><p className="note-text">ผู้ใช้ต้องสมัครและยืนยันอีเมลก่อน การสมัครเองยังไม่ให้สิทธิ์ดูข้อมูลร้าน</p>
 <label className="field"><span>อีเมลสมาชิก</span><Input type="email" value={email} onChange={e=>setEmail(e.target.value)} required disabled={busy||!!edit}/></label>
 <label className="field"><span>บทบาท</span><select value={selectedRole} onChange={e=>{setSelectedRole(e.target.value as MemberRole);setSelected([]);}} disabled={busy}>{choices.map(r=><option value={r} key={r}>{roleLabels[r]}</option>)}</select></label>
 {selectedRole!=="admin"&&<fieldset className="space-y-2"><legend>{selectedRole==="store_manager"?"ร้านที่เข้าถึงได้":"สาขาที่เข้าถึงได้"}</legend>{scopeOptions.map(o=><label className="flex gap-2 items-center" key={o.id}><input type="checkbox" checked={selected.includes(o.id)} disabled={busy} onChange={e=>setSelected(v=>e.target.checked?[...v,o.id]:v.filter(id=>id!==o.id))}/>{o.name}</label>)}</fieldset>}
 {edit&&<label className="flex gap-2"><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)} disabled={busy}/>เปิดใช้งานสมาชิก</label>}
 <Button type="submit" disabled={busy||loading||!email.trim()||(selectedRole!=="admin"&&!selected.length)}>บันทึกสิทธิ์</Button>{edit&&<Button type="button" variant="ghost" onClick={reset} disabled={busy}>ยกเลิก</Button>}
 </form></>}
 </section>;
}
function scopeName(id:string|null|undefined,stores:Row[],branches:Row[]){const b=branches.find(b=>b.id===id);return b?`${stores.find(s=>s.id===b.store_id)?.name} / ${b.name}`:"สาขาไม่พร้อมใช้งาน";}
