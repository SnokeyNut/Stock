"use client";
import { useEffect, useState } from "react";
import { command } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
export type MemberRole = "admin" | "operator" | "viewer";
export const roleLabels: Record<MemberRole,string> = {admin:"แอดมิน",operator:"ผู้ปฏิบัติงาน",viewer:"ดูข้อมูลเท่านั้น"};
type Member = {user_id:string;email:string;role:MemberRole;active:boolean};
export function MemberSettings({organizationId,userId,role,onChanged}:{organizationId:string;userId:string;role:MemberRole|undefined;onChanged:()=>Promise<void>}) {
 const [members,setMembers]=useState<Member[]>([]),[error,setError]=useState(""),[loading,setLoading]=useState(false),[busy,setBusy]=useState(false);
 const [email,setEmail]=useState(""),[newRole,setNewRole]=useState<MemberRole>("viewer");
 const [version,setVersion]=useState(0);
 useEffect(()=>{let valid=true;setMembers([]);setError("");
  if(role!=="admin"||!organizationId)return;
  setLoading(true);
  command("list_members",{organization_id:organizationId}).then(data=>{if(valid)setMembers(data as Member[]);})
   .catch(e=>{if(valid)setError(e.message);}).finally(()=>{if(valid)setLoading(false);});
  return()=>{valid=false;};
 },[organizationId,role,version]);
 const save=async(action:string,payload:Record<string,unknown>)=>{
  if(busy)return;setBusy(true);setError("");
  try{await command(action,{organization_id:organizationId,...payload});await onChanged();setVersion(v=>v+1);setEmail("");toast.success("บันทึกสิทธิ์เรียบร้อย");}
  catch(e){setError((e as Error).message);}finally{setBusy(false);}
 };
 return <section className="panel">
  <div className="panel-head"><div><h2>ผู้ใช้และสิทธิ์</h2><p>สิทธิ์ของคุณ: <b>{role?roleLabels[role]:"ยังไม่มีสิทธิ์"}</b> · ใช้กับทุกร้านและทุกสาขาในองค์กรนี้</p></div></div>
  <p className="note-text">แอดมิน: จัดการข้อมูลและผู้ใช้ทั้งหมด · ผู้ปฏิบัติงาน: รับ เบิก นับสต๊อก และสั่งซื้อ · ดูข้อมูลเท่านั้น: เปิดดูข้อมูลและรายงาน</p>
  {role!=="admin"?<p>เฉพาะแอดมินเท่านั้นที่เปลี่ยนสิทธิ์และเพิ่มสมาชิกได้</p>:<>
   <p>ตอนนี้คุณใช้คนเดียวได้ โดยไม่ต้องเพิ่มสมาชิก บัญชีที่สมัครเองจะไม่เห็นข้อมูลร้านจนกว่าแอดมินจะเพิ่มเข้ามา</p>
   {error&&<p role="alert" className="note-text">{error}</p>}
   {loading?<p>กำลังโหลดสมาชิก…</p>:<div className="table-wrap"><table className="w-full text-sm"><thead><tr><th>บัญชี</th><th>สิทธิ์</th><th>สถานะ</th></tr></thead><tbody>
    {members.map(m=><tr key={m.user_id}><td className="p-3">{m.email}{m.user_id===userId&&" (คุณ)"}</td>
     <td className="p-3"><select aria-label={`สิทธิ์ ${m.email}`} value={m.role} disabled={busy||m.user_id===userId} onChange={e=>void save("set_member_role",{user_id:m.user_id,role:e.target.value,active:m.active})}>
      {Object.entries(roleLabels).map(([value,label])=><option value={value} key={value}>{label}</option>)}
     </select></td><td className="p-3"><Button variant="outline" disabled={busy||m.user_id===userId} onClick={()=>void save("set_member_role",{user_id:m.user_id,role:m.role,active:!m.active})}>{m.active?"เปิดใช้งาน":"ระงับสิทธิ์"}</Button></td></tr>)}
   </tbody></table></div>}
   <p className="note-text">บัญชีแอดมินของคุณเปลี่ยนสิทธิ์ตัวเองไม่ได้ เพื่อป้องกันการล็อกตัวเองออกจากองค์กร การระงับสิทธิ์มีผลกับข้อมูลและการบันทึกขององค์กรนี้</p>
   <details><summary>เพิ่มสมาชิกที่มีบัญชีแล้ว</summary><form className="space-y-3 mt-3" onSubmit={e=>{e.preventDefault();void save("add_member",{email,role:newRole});}}>
    <p>ผู้ใช้ต้องมีบัญชีและยืนยันอีเมลแล้ว ขั้นตอนนี้เพิ่มสิทธิ์เข้าองค์กร ไม่มีการส่งอีเมลเชิญ</p>
    <label className="field"><span>อีเมลสมาชิก</span><Input type="email" value={email} onChange={e=>setEmail(e.target.value)} required disabled={busy}/></label>
    <label className="field"><span>สิทธิ์เริ่มต้น</span><select value={newRole} onChange={e=>setNewRole(e.target.value as MemberRole)} disabled={busy}>{Object.entries(roleLabels).map(([value,label])=><option value={value} key={value}>{label}</option>)}</select></label>
    <Button type="submit" disabled={busy||loading||!email.trim()}>เพิ่มสมาชิก</Button>
   </form></details>
  </>}
 </section>;
}
