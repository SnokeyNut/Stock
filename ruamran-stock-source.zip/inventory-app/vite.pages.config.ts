import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath} from 'node:url';
export default defineConfig({root:'pages-entry',base:'./',plugins:[react()],resolve:{alias:{'@':fileURLToPath(new URL('.',import.meta.url))}},build:{outDir:'../pages-dist',emptyOutDir:true,assetsInlineLimit:1000000,cssCodeSplit:false,rollupOptions:{output:{inlineDynamicImports:true}}}});
