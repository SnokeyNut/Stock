import assert from 'node:assert/strict';
import {suggestion,renderTemplate,today} from '../lib/inventory.ts';
assert.equal(suggestion(2,3,20,2,5),4); // 18kg deficit rounded to 4 bags.
assert.equal(suggestion(4,3,20,1,5),0);
assert.equal(suggestion(2,3,null,1,5),0);
assert.equal(suggestion(0,0,1,null,1),1);
assert.equal(renderTemplate('{store}\n{items}',{store:'ร้าน A',items:'หมู 2 กก.'}),'ร้าน A\nหมู 2 กก.');
assert.match(today(),/^\d{4}-\d{2}-\d{2}$/);
console.log('PASS: reorder rounding, threshold, missing targets, template, Bangkok date');
