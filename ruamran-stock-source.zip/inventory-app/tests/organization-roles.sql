-- Transaction-only fixtures: all auth users, memberships and documents roll back.
begin;
do $$ declare a uuid:=gen_random_uuid();v uuid:=gen_random_uuid();p uuid:=gen_random_uuid();x uuid:=gen_random_uuid();o uuid; begin
insert into auth.users(id,email,email_confirmed_at) values
 (a,a||'@roles-test.invalid',now()),(v,v||'@roles-test.invalid',now()),(p,p||'@roles-test.invalid',now()),(x,x||'@roles-test.invalid',now());
insert into public.organizations(name) values('roles test') returning id into o;
insert into public.organization_members(organization_id,user_id,role) values(o,a,'admin'),(o,v,'viewer'),(o,p,'operator');
perform set_config('test.admin',a::text,true);perform set_config('test.viewer',v::text,true);
perform set_config('test.operator',p::text,true);perform set_config('test.outsider',x::text,true);perform set_config('test.org',o::text,true);
end $$;
set local role authenticated;
do $$ declare o uuid:=current_setting('test.org')::uuid; a uuid:=current_setting('test.admin')::uuid;
v uuid:=current_setting('test.viewer')::uuid;p uuid:=current_setting('test.operator')::uuid;
result jsonb; idempotency uuid:=gen_random_uuid(); q jsonb; begin
perform set_config('request.jwt.claims',jsonb_build_object('sub',a,'role','authenticated')::text,true);
result:=public.app_command('list_members',jsonb_build_object('organization_id',o),gen_random_uuid());
if jsonb_array_length(result)<>3 then raise exception 'member list incorrect';end if;
q:=jsonb_build_object('organization_id',o,'entity','stores','record',jsonb_build_object('name','test-store'));
result:=public.app_command('save_entity',q,idempotency);
if result is distinct from public.app_command('save_entity',q,idempotency) then raise exception 'idempotency failed';end if;
if (select count(*) from public.stores where organization_id=o)<>1 then raise exception 'duplicate store';end if;
perform public.app_command('save_entity',jsonb_build_object('organization_id',o,'entity','branches','record',jsonb_build_object('store_id',(result->>'id')::uuid,'name','test branch')),gen_random_uuid());
perform public.app_command('set_member_role',jsonb_build_object('organization_id',o,'user_id',v,'role','viewer','active',true,'scopes',jsonb_build_array(jsonb_build_object('branch_id',(select id from public.branches where store_id=(result->>'id')::uuid)))),gen_random_uuid());
begin
perform public.app_command('set_member_role',jsonb_build_object('organization_id',o,'user_id',a,'role','viewer','active',true),gen_random_uuid());
raise exception 'self demotion allowed';exception when others then if sqlerrm='self demotion allowed' then raise;end if;end;
perform set_config('request.jwt.claims',jsonb_build_object('sub',p,'role','authenticated')::text,true);
begin
perform public.app_command('list_members',jsonb_build_object('organization_id',o),gen_random_uuid());
raise exception 'operator list allowed';exception when others then if sqlerrm='operator list allowed' then raise;end if;end;
begin
perform public.app_command('save_entity',q,gen_random_uuid());
raise exception 'operator master write allowed';exception when others then if sqlerrm='operator master write allowed' then raise;end if;end;
begin
perform app_private.command_workflows('save_entity',q,gen_random_uuid());
raise exception 'workflow bypass allowed';exception when insufficient_privilege then null;end;
begin
update public.organization_members set role='admin' where organization_id=o and user_id=p;
raise exception 'direct promotion allowed';exception when insufficient_privilege then null;end;
perform set_config('request.jwt.claims',jsonb_build_object('sub',v,'role','authenticated')::text,true);
if (select count(*) from public.stores where organization_id=o)<>1 then raise exception 'viewer read failed';end if;
begin
perform public.app_command('issue',jsonb_build_object('organization_id',o),gen_random_uuid());
raise exception 'viewer stock write allowed';exception when others then if sqlerrm not like '%ดูข้อมูลเท่านั้น%' then raise;end if;end;
-- Revoke a member, then verify RLS and all commands immediately deny that membership.
perform set_config('request.jwt.claims',jsonb_build_object('sub',a,'role','authenticated')::text,true);
perform public.app_command('set_member_role',jsonb_build_object('organization_id',o,'user_id',v,'role','viewer','active',false,'scopes',jsonb_build_array(jsonb_build_object('branch_id',(select id from public.branches where app_private.branch_org(id)=o)))),gen_random_uuid());
perform set_config('request.jwt.claims',jsonb_build_object('sub',v,'role','authenticated')::text,true);
if exists(select 1 from public.stores where organization_id=o) then raise exception 'revoked reads allowed';end if;
begin
perform public.app_command('list_members',jsonb_build_object('organization_id',o),gen_random_uuid());
raise exception 'revoked command allowed';exception when others then if sqlerrm not like '%ไม่มีสิทธิ์เข้าถึงองค์กรนี้%' then raise;end if;end;
perform set_config('request.jwt.claims',jsonb_build_object('sub',current_setting('test.outsider'),'role','authenticated')::text,true);
if exists(select 1 from public.organizations where id=o) then raise exception 'cross-org read allowed';end if;
result:=public.app_command('create_organization','{"name":"new role org"}',gen_random_uuid());
if app_private.current_role((result->>'id')::uuid)<>'admin' then raise exception 'new creator not admin';end if;
end $$;
select 'PASS: admin, viewer, operator, revocation, cross-org isolation, direct-write denial, creator admin and idempotency' as result;
rollback;
