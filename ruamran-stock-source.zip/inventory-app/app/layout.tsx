import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "รวมร้าน · ระบบสต๊อก",
  description: "ระบบสต๊อกหลายร้านหลายสาขา เชื่อม Supabase",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="th">
      <body className="antialiased">{children}</body>
    </html>
  );
}
