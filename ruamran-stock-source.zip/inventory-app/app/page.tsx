"use client";
import { useEffect, useRef, useState, useMemo } from "react";
import {
  Package,
  LayoutDashboard,
  Boxes,
  ClipboardCheck,
  ShoppingCart,
  Users,
  BarChart3,
  Settings,
  Sparkles,
  ArrowDownToLine,
  ArrowUpFromLine,
  Plus,
  Search,
  RefreshCw,
  ArrowRight,
  Copy,
  LogOut,
  Store,
  CheckCircle2,
  AlertTriangle,
  Download,
  ChevronRight,
  Clock,
  ReceiptText,
  Pencil,
} from "lucide-react";
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import { supabase, command } from "@/lib/supabase";
import {
  TABLES,
  emptyData,
  today,
  number,
  dateLabel,
  suggestion,
  renderTemplate,
  type Data,
  type Row,
} from "@/lib/inventory";
import type { Session } from "@supabase/supabase-js";
import { MemberSettings, type MemberRole } from "@/components/member-settings";
const menus = [
  ["dashboard", LayoutDashboard, "ภาพรวม"],
  ["stock", Boxes, "สต๊อกสินค้า"],
  ["receive", ArrowDownToLine, "รับสินค้าเข้า"],
  ["issue", ArrowUpFromLine, "เบิกสินค้า"],
  ["count", ClipboardCheck, "เช็คสต๊อกรายวัน"],
  ["orders", ShoppingCart, "รายการสั่งซื้อ"],
  ["suppliers", Users, "ผู้ขาย"],
  ["reports", BarChart3, "รายงาน"],
  ["settings", Settings, "จัดการข้อมูล"],
  ["future", Sparkles, "AI & วิเคราะห์"],
] as const;
const defaultTemplate =
  "ร้าน: {store}\nวันที่: {date}\nสาขา: {branch}\nผู้ขาย: {supplier}\n\n{items}";
const masterLabels: Record<string, string> = {
  stores: "ร้าน",
  branches: "สาขา",
  suppliers: "ผู้ขาย",
  categories: "ประเภทสินค้า",
  products: "สินค้า",
};
type OrderLine = {
  product_id: string;
  quantity: string;
  unit_price: string;
  unit: string;
  suggested_quantity?: number;
  expected_quantity?: number;
};
function Picker({
  value,
  onChange,
  options,
  placeholder = "เลือก",
  disabled = false,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { id: string; name?: string }[];
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <Select
      value={value || undefined}
      onValueChange={onChange}
      disabled={disabled}
    >
      <SelectTrigger className="picker" aria-label={placeholder}>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem value={o.id} key={o.id}>
            {o.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}
function Empty({
  title = "ยังไม่มีรายการ",
  text = "เพิ่มข้อมูลเพื่อเริ่มใช้งาน",
  action,
}: {
  title?: string;
  text?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="empty">
      <Package size={36} />
      <h3>{title}</h3>
      <p>{text}</p>
      {action}
    </div>
  );
}
function GridTable({
  heads,
  children,
}: {
  heads: string[];
  children: React.ReactNode;
}) {
  return (
    <div className="table-wrap">
      <Table>
        <TableHeader>
          <TableRow>
            {heads.map((h) => (
              <TableHead key={h}>{h}</TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>{children}</TableBody>
      </Table>
    </div>
  );
}
export default function Page() {
  const [session, setSession] = useState<Session | null>(null),
    [authReady, setAuthReady] = useState(false),
    [data, setData] = useState<Data>(emptyData),
    [loading, setLoading] = useState(false),
    [error, setError] = useState("");
  const [page, setPage] = useState("dashboard"),
    [orgId, setOrgId] = useState(""),
    [storeId, setStoreId] = useState("all"),
    [branchId, setBranchId] = useState("all"),
    [search, setSearch] = useState(""),
    [category, setCategory] = useState("all");
  const [authOpen, setAuthOpen] = useState(false),
    [authMode, setAuthMode] = useState("login"),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [authBusy, setAuthBusy] = useState(false);
  const [busy, setBusy] = useState(false),
    [orgName, setOrgName] = useState("รวมร้าน"),
    [master, setMaster] = useState("products"),
    [editor, setEditor] = useState<{
      entity: string;
      record: Row | Record<string, any>;
    } | null>(null);
  const [supplierDetail, setSupplierDetail] = useState<string | null>(null),
    [template, setTemplate] = useState(defaultTemplate),
    [priceOpen, setPriceOpen] = useState(false),
    [priceForm, setPriceForm] = useState({
      product_id: "",
      supplier_id: "",
      price: "",
      unit: "",
      conversion: "1",
      date: today(),
    });
  const [lines, setLines] = useState<OrderLine[]>([]),
    [formSupplier, setFormSupplier] = useState(""),
    [formDate, setFormDate] = useState(today()),
    [note, setNote] = useState(""),
    [docNumber, setDocNumber] = useState(""),
    [receiptOrder, setReceiptOrder] = useState("");
  const [countValues, setCountValues] = useState<Record<string, string>>({}),
    [countSnapshot, setCountSnapshot] = useState<Record<string, number>>({}),
    [orderEdit, setOrderEdit] = useState<{
      supplier: string;
      lines: OrderLine[];
    } | null>(null);
  const [reportFrom, setReportFrom] = useState(today()),
    [reportTo, setReportTo] = useState(today());
  const loadGeneration = useRef(0),
    pending = useRef(false),
    retryRequest = useRef<{ fingerprint: string; id: string } | null>(null),
    sessionRef = useRef<Session | null>(null);
  const reload = async () => {
    const generation = ++loadGeneration.current;
    if (!sessionRef.current) {
      setData(emptyData());
      return;
    }
    setLoading(true);
    setError("");
    try {
      const entries = await Promise.all(
        TABLES.map(async (t) => {
          const rows: Row[] = [];
          for (let offset = 0; ; offset += 1000) {
            const { data: r, error: e } = await supabase
              .from(t)
              .select("*")
              .order(t === "organization_settings" ? "organization_id" : t === "organization_members" ? "user_id" : "id")
              .range(offset, offset + 999);
            if (e) throw new Error(e.message);
            rows.push(...(r as Row[]));
            if (r.length < 1000) break;
          }
          return [t, rows] as const;
        }),
      );
      if (generation === loadGeneration.current) {
        setData(Object.fromEntries(entries) as Data);
      }
    } catch (e) {
      if (generation === loadGeneration.current) {
        setError((e as Error).message);
      }
    } finally {
      if (generation === loadGeneration.current) setLoading(false);
    }
  };
  useEffect(() => {
    supabase.auth.getSession().then(({ data, error }) => {
      if (error) setError(error.message);
      sessionRef.current = data.session;
      setSession(data.session);
      setAuthReady(true);
    });
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, s) => {
      sessionRef.current = s;
      setSession(s);
      setAuthReady(true);
      if (!s) {
        ++loadGeneration.current;
        setData(emptyData());
        setOrgId("");
        setLoading(false);
        setAuthOpen(false);
      }
    });
    return () => subscription.unsubscribe();
  }, []);
  useEffect(() => {
    if (session) void reload();
  }, [session?.user.id]);
  useEffect(() => {
    const update = () => {
      const hash = location.hash.slice(1);
      if (menus.some((m) => m[0] === hash)) setPage(hash);
    };
    update();
    window.addEventListener("hashchange", update);
    return () => window.removeEventListener("hashchange", update);
  }, []);
  useEffect(() => {
    if (
      data.organizations.length &&
      !data.organizations.some((o) => o.id === orgId)
    ) {
      setOrgId(data.organizations[0].id);
    }
  }, [data.organizations, orgId]);
  useEffect(() => {
    setStoreId("all");
    setBranchId("all");
    setFormSupplier("");
    setLines([]);
  }, [orgId]);
  const org = data.organizations.find((o) => o.id === orgId);
  const stores = data.stores.filter((s) => s.organization_id === orgId),
    suppliers = data.suppliers.filter((s) => s.organization_id === orgId),
    categories = data.categories.filter((c) => c.organization_id === orgId),
    products = data.products.filter((p) => p.organization_id === orgId);
  const branches = data.branches.filter(
    (b) =>
      stores.some((s) => s.id === b.store_id) &&
      (storeId === "all" || b.store_id === storeId),
  );
  const scopedBranches = branches.filter(
      (b) => branchId === "all" || b.id === branchId,
    ),
    branchIds = new Set(scopedBranches.map((b) => b.id)),
    branch = data.branches.find((b) => b.id === branchId),
    store = data.stores.find((s) => s.id === branch?.store_id);
  const activeProducts = products.filter((p) => p.active),
    activeSuppliers = suppliers.filter((s) => s.active);
  const stockFor = (product: string, b: string) =>
    Number(
      data.branch_stock.find(
        (s) => s.product_id === product && s.branch_id === b,
      )?.quantity ?? 0,
    );
  const priceFor = (p: Row) =>
    p.supplier_id
      ? data.supplier_products.find(
          (s) => s.product_id === p.id && s.supplier_id === p.supplier_id,
        )
      : (data.supplier_products.find(
          (s) => s.product_id === p.id && s.is_preferred,
        ) ?? data.supplier_products.find((s) => s.product_id === p.id));
  const stockPrice = (p: Row) => {
    const x = priceFor(p);
    return x?.last_price != null
      ? Number(x.last_price) / Number(x.conversion_to_stock_unit || 1)
      : null;
  };
  const stockRows: (Row & {
    branch_id: string;
    branch_name: string;
    quantity: number;
  })[] = scopedBranches.flatMap((b) =>
    activeProducts.map((p) => ({
      ...p,
      branch_id: b.id,
      branch_name: b.name,
      quantity: stockFor(p.id, b.id),
    })),
  );
  const filteredStock = stockRows.filter(
    (p) =>
      (category === "all" || p.category_id === category) &&
      (p.name + " " + (p.code ?? ""))
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  const lowStock = stockRows.filter((p) => p.quantity <= Number(p.min_stock)),
    movements = data.stock_movements.filter((m) => branchIds.has(m.branch_id));
  const dayMovements = movements.filter(
    (m) =>
      new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Bangkok" }).format(
        new Date(m.created_at),
      ) === today(),
  );
  const orders = data.purchase_orders.filter((p) => branchIds.has(p.branch_id));
  const candidates =
    branchId === "all"
      ? []
      : activeProducts.flatMap((p) => {
          const sp = priceFor(p),
            sup = suppliers.find(
              (s) => s.id === (p.supplier_id ?? sp?.supplier_id) && s.active,
            );
          if (!sup) return [];
          const conversion = Number(sp?.conversion_to_stock_unit || 1);
          const outstanding = data.purchase_order_items
            .filter(
              (i) =>
                i.product_id === p.id &&
                data.purchase_orders.some(
                  (o) =>
                    o.id === i.purchase_order_id &&
                    o.branch_id === branchId &&
                    ["draft", "ordered"].includes(o.status),
                ),
            )
            .reduce((sum, i) => {
              const po = data.purchase_orders.find(
                (o) => o.id === i.purchase_order_id,
              );
              const map = data.supplier_products.find(
                (s) =>
                  s.product_id === p.id && s.supplier_id === po?.supplier_id,
              );
              const received = data.goods_receipt_items
                .filter(
                  (gi) =>
                    gi.product_id === p.id &&
                    data.goods_receipts.some(
                      (gr) =>
                        gr.id === gi.goods_receipt_id &&
                        gr.purchase_order_id === i.purchase_order_id,
                    ),
                )
                .reduce((total, gi) => total + Number(gi.quantity), 0);
              return (
                sum +
                Math.max(
                  0,
                  Number(i.ordered_quantity) *
                    Number(i.conversion_to_stock_unit || 1) -
                    received,
                )
              );
            }, 0);
          const q = suggestion(
            stockFor(p.id, branchId) + outstanding,
            Number(p.min_stock),
            p.target_stock == null ? null : Number(p.target_stock),
            p.reorder_multiple == null ? null : Number(p.reorder_multiple),
            conversion,
          );
          return q > 0
            ? [
                {
                  product: p,
                  supplier: sup,
                  quantity: q,
                  price: sp?.last_price ?? null,
                  unit: sp?.purchase_unit ?? p.unit,
                  category:
                    categories.find((c) => c.id === p.category_id)?.name ??
                    "ไม่ระบุประเภท",
                },
              ]
            : [];
        });
  const filteredCandidates = candidates.filter(
    (c) => category === "all" || c.product.category_id === category,
  );
  useEffect(() => {
    setTemplate(
      data.organization_settings.find((s) => s.organization_id === orgId)
        ?.order_template ?? defaultTemplate,
    );
  }, [data.organization_settings, orgId]);
  useEffect(() => {
    setLines([]);
    setReceiptOrder("");
    setNote("");
    setDocNumber("");
    setCountValues({});
    setCountSnapshot(
      Object.fromEntries(
        activeProducts.map((p) => [p.id, stockFor(p.id, branchId)]),
      ),
    );
  }, [branchId, page, orgId]);
  useEffect(() => {
    if (branchId !== "all" && !branches.some((b) => b.id === branchId))
      setBranchId("all");
  }, [data.branches, storeId]);
  const navigate = (p: string) => {
    setPage(p);
    setSearch("");
    setCategory("all");
    location.hash = p;
  };
  const run = async (
    action: string,
    payload: Record<string, unknown>,
    success = "บันทึกเรียบร้อย",
  ) => {
    if (pending.current) return false;
    pending.current = true;
    setBusy(true);
    try {
      const body = { organization_id: orgId, ...payload };
      const fingerprint = JSON.stringify({ action, body });
      if (retryRequest.current?.fingerprint !== fingerprint) retryRequest.current = { fingerprint, id: crypto.randomUUID() };
      await command(action, body, retryRequest.current.id);
      retryRequest.current = null;
      toast.success(success);
      await reload();
      return true;
    } catch (e) {
      toast.error((e as Error).message);
      return false;
    } finally {
      pending.current = false;
      setBusy(false);
    }
  };
  const auth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthBusy(true);
    try {
      if (authMode === "login") {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        setAuthOpen(false);
        setPassword("");
      } else {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (data.session) {
          setAuthOpen(false);
        } else toast.success("ตรวจอีเมลเพื่อยืนยันบัญชี แล้วกลับมาเข้าสู่ระบบ");
        setPassword("");
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setAuthBusy(false);
    }
  };
  const createOrg = async () => {
    if (
      await run(
        "create_organization",
        { name: orgName },
        "สร้างองค์กรเรียบร้อย",
      )
    )
      navigate("settings");
  };
  const myRole = data.organization_members.find(m => m.organization_id === orgId && m.user_id === session?.user.id && m.active)?.role as MemberRole | undefined;
  const canWrite = !!session && !!org && !!myRole && myRole !== "viewer" && !loading && !error;
  const canAdmin = canWrite && myRole === "admin";
  const ensureBranch = branchId !== "all" && !!branch?.active;
  const saveMaster = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editor) return;
    if (
      await run("save_entity", { entity: editor.entity, record: editor.record })
    )
      setEditor(null);
  };
  const editRecord = (entity: string, row?: Row) =>
    setEditor({
      entity,
      record: row
        ? { ...row }
        : {
            name: "",
            code: "",
            active: true,
            ...(entity === "branches"
              ? { store_id: stores.find((s) => s.active)?.id ?? "" }
              : {}),
            ...(entity === "products"
              ? {
                  unit: "กก.",
                  min_stock: 0,
                  target_stock: 0,
                  reorder_multiple: 1,
                  category_id: null,
                  supplier_id: null,
                }
              : {}),
            ...(entity === "suppliers"
              ? { contact_name: "", line_name: "", line_id: "", notes: "" }
              : {}),
          },
    });
  const updateRecord = (key: string, value: unknown) =>
    setEditor((prev) =>
      prev ? { ...prev, record: { ...prev.record, [key]: value } } : null,
    );
  const addLine = () =>
    setLines((l) => [
      ...l,
      { product_id: "", quantity: "", unit_price: "", unit: "" },
    ]);
  const updateLine = (index: number, key: string, value: string) =>
    setLines((ls) =>
      ls.map((l, i) =>
        i === index
          ? {
              ...l,
              [key]: value,
              ...(key === "product_id"
                ? { unit: products.find((p) => p.id === value)?.unit ?? "" }
                : {}),
            }
          : l,
      ),
    );
  const submitStock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ensureBranch) return toast.error("เลือกสาขาก่อนบันทึก");
    if (!lines.length || lines.some((l) => !l.product_id || !l.quantity))
      return toast.error("กรอกสินค้าและจำนวนให้ครบ");
    if (
      await run(page, {
        branch_id: branchId,
        supplier_id: formSupplier || null,
        purchase_order_id: receiptOrder || null,
        date: formDate,
        document_number: docNumber,
        note,
        items: lines.map((l) => ({
          ...l,
          quantity: Number(l.quantity),
          unit_price: l.unit_price === "" ? null : Number(l.unit_price),
        })),
      })
    ) {
      setLines([]);
      setReceiptOrder("");
      setNote("");
      setDocNumber("");
    }
  };
  const submitCount = async () => {
    const items = activeProducts
      .filter(
        (p) => countValues[p.id] !== undefined && countValues[p.id] !== "",
      )
      .map((p) => ({
        product_id: p.id,
        quantity: Number(countValues[p.id]),
        expected_quantity: countSnapshot[p.id],
      }));
    if (!items.length) return toast.error("กรอกยอดนับจริงอย่างน้อยหนึ่งรายการ");
    if (
      await run("count", { branch_id: branchId, date: formDate, note, items })
    ) {
      setCountValues({});
      setCountSnapshot(
        Object.fromEntries(
          activeProducts.map((p) => [p.id, stockFor(p.id, branchId)]),
        ),
      );
    }
  };
  const refreshCount = async () => {
    await reload();
    setCountValues({});
  };
  useEffect(() => {
    if (page === "count" && Object.values(countValues).every((v) => v === ""))
      setCountSnapshot(
        Object.fromEntries(
          activeProducts.map((p) => [p.id, stockFor(p.id, branchId)]),
        ),
      );
  }, [data.branch_stock, page, branchId, countValues]);
  const todaysOrders = (supplier: string) =>
    orders.filter(
      (o) =>
        o.supplier_id === supplier &&
        o.order_date === today() &&
        o.status !== "cancelled",
    );
  const orderText = (supplier: string) => {
    const pos = todaysOrders(supplier);
    return pos
      .map((po) => {
        const b = data.branches.find((b) => b.id === po.branch_id),
          s = data.stores.find((s) => s.id === b?.store_id);
        const items = data.purchase_order_items
          .filter((i) => i.purchase_order_id === po.id)
          .map((i) => {
            const p = products.find((p) => p.id === i.product_id);
            return `${categories.find((c) => c.id === p?.category_id)?.name ?? "ไม่ระบุประเภท"} · ${p?.name ?? "สินค้า"} ${number(Number(i.ordered_quantity))} ${i.unit}${i.unit_price != null ? " @ " + number(Number(i.unit_price)) + " บาท" : ""}`;
          })
          .join("\n");
        return renderTemplate(template, {
          store: s?.name ?? "",
          branch: b?.name ?? "",
          supplier: suppliers.find((s) => s.id === supplier)?.name ?? "",
          date: dateLabel(po.order_date),
          items,
        });
      })
      .join("\n\n────────────\n\n");
  };
  const selectReceiptOrder = (id: string) => {
    setReceiptOrder(id === "none" ? "" : id);
    if (id === "none") {
      setLines([]);
      return;
    }
    const po = orders.find((o) => o.id === id);
    if (!po) return;
    setFormSupplier(po.supplier_id);
    setLines(
      data.purchase_order_items
        .filter((i) => i.purchase_order_id === id)
        .flatMap((i) => {
          const p = products.find((p) => p.id === i.product_id);
          if (!p) return [];
          const received = data.goods_receipt_items
            .filter(
              (gi) =>
                gi.product_id === p.id &&
                data.goods_receipts.some(
                  (gr) =>
                    gr.id === gi.goods_receipt_id &&
                    gr.purchase_order_id === id,
                ),
            )
            .reduce((n, gi) => n + Number(gi.quantity), 0);
          const q =
            Number(i.ordered_quantity) *
              Number(i.conversion_to_stock_unit || 1) -
            received;
          return q > 0
            ? [
                {
                  product_id: p.id,
                  quantity: String(q),
                  unit: p.unit,
                  unit_price:
                    i.unit_price == null
                      ? ""
                      : String(
                          Number(i.unit_price) /
                            Number(i.conversion_to_stock_unit || 1),
                        ),
                },
              ]
            : [];
        }),
    );
  };
  const copyOrder = async (supplier: string) => {
    try {
      await navigator.clipboard.writeText(orderText(supplier));
      toast.success("คัดลอกข้อความแล้ว");
    } catch {
      toast.error("คัดลอกไม่ได้ กรุณาเลือกข้อความในช่องแล้วคัดลอกด้วยตัวเอง");
    }
  };
  const exportCsv = (
    heads: string[],
    rows: (string | number)[][],
    name: string,
  ) => {
    const escape = (v: string | number) =>
      '"' +
      (typeof v === "string" && /^[=+\-@\t\r]/.test(v)
        ? "'" + v
        : String(v)
      ).replaceAll('"', '""') +
      '"';
    const blob = new Blob(
      [
        "\ufeff" +
          [heads, ...rows].map((r) => r.map(escape).join(",")).join("\r\n"),
      ],
      { type: "text/csv;charset=utf-8" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  useEffect(() => {
    const ctx = (document as any).modelContext;
    if (!ctx?.registerTool) return;
    const lifecycle = new AbortController();
    Promise.resolve(
      ctx.registerTool(
        {
          name: "navigate_inventory",
          description:
            "Open a section of the inventory workspace. Does not change records.",
          inputSchema: {
            type: "object",
            properties: {
              page: { type: "string", enum: menus.map((m) => m[0]) },
            },
            required: ["page"],
            additionalProperties: false,
          },
          annotations: { readOnlyHint: true },
          execute: (input: unknown) => {
            const p = (input as any)?.page;
            if (!menus.some((m) => m[0] === p)) throw new Error("Invalid page");
            navigate(p);
            return { page: p };
          },
        },
        { signal: lifecycle.signal },
      ),
    ).catch(() => {});
    return () => lifecycle.abort();
  }, []);
  const statusLabel: Record<string, string> = {
    draft: "ร่าง",
    ordered: "สั่งแล้ว",
    received: "รับครบแล้ว",
    cancelled: "ยกเลิก",
  };
  const branchWarning = (
    <div className="notice">
      <Store size={18} />
      <span>เลือกสาขาด้านบนเพื่อทำรายการ ยอดสต๊อกจะบันทึกแยกตามสาขา</span>
    </div>
  );
  const filterBar = (
    <div className="toolbar">
      <div className="search">
        <Search size={17} />
        <Input
          aria-label="ค้นหาสินค้า"
          placeholder="ค้นหาชื่อหรือรหัสสินค้า"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      <Picker
        value={category}
        onChange={setCategory}
        options={[{ id: "all", name: "ทุกประเภท" }, ...categories]}
        placeholder="ประเภทสินค้า"
      />
    </div>
  );
  return (
    <SidebarProvider>
      <Toaster richColors position="top-right" />
      <Sidebar>
        <SidebarHeader>
          <div className="brand">
            <Package />
            <div>
              รวมร้าน<small>INVENTORY WORKSPACE</small>
            </div>
          </div>
          <div className="org-picker">
            <Picker
              value={orgId}
              onChange={setOrgId}
              options={data.organizations}
              placeholder="เลือกองค์กร"
              disabled={!data.organizations.length}
            />
          </div>
        </SidebarHeader>
        <SidebarContent>
          <div className="nav-caption">จัดการสต๊อก</div>
          <SidebarMenu>
            {menus.map(([key, Icon, title]) => (
              <SidebarMenuItem key={key}>
                <SidebarMenuButton
                  isActive={page === key}
                  onClick={() => navigate(key)}
                >
                  <Icon />
                  <span>{title}</span>
                  {key === "future" && <span className="nav-soon">SOON</span>}
                  {key === "orders" && candidates.length > 0 && (
                    <span className="nav-count">{candidates.length}</span>
                  )}
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter>
          <div className="sidebar-bottom">
            <span className="online-dot" />
            Supabase · Phase 1<small>ข้อมูลของร้านคุณ ในพื้นที่เดียว</small>
          </div>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header>
          <SidebarTrigger />
          <div className="context-pickers">
            <Picker
              value={storeId}
              onChange={(v) => {
                setStoreId(v);
                setBranchId("all");
              }}
              options={[{ id: "all", name: "ทุกร้าน" }, ...stores]}
              placeholder="เลือกร้าน"
            />
            <ChevronRight size={14} />
            <Picker
              value={branchId}
              onChange={setBranchId}
              options={[{ id: "all", name: "ทุกสาขา" }, ...branches]}
              placeholder="เลือกสาขา"
            />
          </div>
          <div className="header-actions">
            <Button
              variant="ghost"
              size="icon"
              aria-label="รีเฟรชข้อมูล"
              disabled={!session || loading}
              onClick={() => void reload()}
            >
              <RefreshCw className={loading ? "spin" : ""} size={17} />
            </Button>
            {session ? (
              <Button
                variant="outline"
                onClick={() => void supabase.auth.signOut()}
              >
                <LogOut size={15} />
                <span className="hide-mobile">ออกจากระบบ</span>
              </Button>
            ) : (
              <Button onClick={() => setAuthOpen(true)}>เข้าสู่ระบบ</Button>
            )}
          </div>
        </header>
        <main>
          <div className="heading">
            <div>
              <div className="eyebrow">
                {org?.name ?? "พื้นที่จัดการร้าน"} <span>/</span>{" "}
                {menus.find((m) => m[0] === page)?.[2]}
              </div>
              <h1>
                {page === "dashboard"
                  ? "สต๊อกพร้อม ร้านพร้อม"
                  : menus.find((m) => m[0] === page)?.[2]}
              </h1>
              <p>
                {page === "dashboard"
                  ? `${dateLabel(today())} · ${store?.name ?? "ภาพรวมทุกร้าน"}${branch ? " / " + branch.name : ""}`
                  : page === "suppliers"
                    ? "ผู้ติดต่อ รายการสั่งซื้อ และข้อความพร้อมคัดลอก"
                    : page === "orders"
                      ? "เติมสต๊อกตามเป้าหมาย แยกตามผู้ขายและประเภท"
                      : page === "count"
                        ? "นับยอดจริง ตรวจผลต่าง แล้วบันทึกปรับยอดสต๊อก"
                        : page === "future"
                          ? "พื้นที่สำหรับฟังก์ชันที่จะเพิ่มในระยะถัดไป"
                          : "ข้อมูลแยกตามร้านและสาขาที่เลือก"}
              </p>
            </div>
            {page === "dashboard" && (
              <Button disabled={!canWrite} onClick={() => navigate("receive")}>
                <Plus size={17} />
                รับสินค้าเข้า
              </Button>
            )}
            {page === "suppliers" && (
              <Button
                disabled={!canAdmin}
                onClick={() => editRecord("suppliers")}
              >
                <Plus size={17} />
                เพิ่มผู้ขาย
              </Button>
            )}
          </div>
          {error && (
            <div className="notice danger">
              <AlertTriangle size={18} />
              <div>
                โหลดข้อมูลไม่สำเร็จ: {error}
                <Button variant="link" onClick={() => void reload()}>
                  ลองใหม่
                </Button>
              </div>
            </div>
          )}
          {!authReady && <Skeleton className="h-24 w-full" />}
          {authReady && !session && (
            <div className="notice welcome">
              <Package size={24} />
              <div>
                <b>เชื่อมต่อพื้นที่สต๊อกของคุณ</b>
                <p>
                  เข้าสู่ระบบหรือสร้างบัญชี เพื่อเริ่มเพิ่มร้าน สาขา และวัตถุดิบ
                </p>
              </div>
              <Button onClick={() => setAuthOpen(true)}>
                เริ่มใช้งาน
                <ArrowRight size={16} />
              </Button>
            </div>
          )}
          {session && !loading && !data.organizations.length && !error && (
            <section className="panel onboarding">
              <h2>สร้างองค์กรแรกของคุณ</h2>
              <p>
                องค์กรเป็นพื้นที่รวมร้านและสาขา เช่น ก๋วยเตี๋ยวปลาและสยามสุกี้
              </p>
              <Field label="ชื่อองค์กร">
                <Input
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                />
              </Field>
              <Button
                disabled={busy || !orgName.trim()}
                onClick={() => void createOrg()}
              >
                สร้างองค์กร
              </Button>
            </section>
          )}
          {loading && <div className="loading-line">กำลังอัปเดตข้อมูล…</div>}
          {page === "dashboard" && (
            <>
              <section className="metrics">
                {[
                  [
                    Boxes,
                    "สินค้าทั้งหมด",
                    activeProducts.length,
                    "รายการวัตถุดิบที่เปิดใช้งาน",
                  ],
                  [
                    AlertTriangle,
                    "ใกล้หมด / ต้องสั่ง",
                    lowStock.length,
                    "รายการแยกตามสาขา",
                  ],
                  [
                    ArrowDownToLine,
                    "รับเข้า วันนี้",
                    dayMovements.filter((m) => m.movement_type === "receive")
                      .length,
                    "รายการเคลื่อนไหว",
                  ],
                  [
                    ArrowUpFromLine,
                    "เบิกออก วันนี้",
                    dayMovements.filter((m) => m.movement_type === "issue")
                      .length,
                    "รายการเคลื่อนไหว",
                  ],
                ].map(([Icon, label, v, sub], i) => {
                  const I = Icon as typeof Boxes;
                  return (
                    <article className="metric" key={String(label)}>
                      <div className="metric-top">
                        <span>{String(label)}</span>
                        <I size={19} className={i === 1 ? "amber" : "green"} />
                      </div>
                      <strong>{session ? number(Number(v)) : "—"}</strong>
                      <small>{String(sub)}</small>
                    </article>
                  );
                })}
              </section>
              <div className="dashboard-grid">
                <article className="panel">
                  <div className="panel-head">
                    <h2>สินค้าที่ต้องเติม</h2>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate("stock")}
                    >
                      ดูทั้งหมด
                      <ArrowRight size={14} />
                    </Button>
                  </div>
                  {lowStock.length ? (
                    <GridTable
                      heads={["สินค้า / สาขา", "คงเหลือ", "ขั้นต่ำ", "สถานะ"]}
                    >
                      {lowStock.slice(0, 6).map((p) => (
                        <TableRow key={p.id + p.branch_id}>
                          <TableCell>
                            <b>{p.name}</b>
                            <small className="subtext">{p.branch_name}</small>
                          </TableCell>
                          <TableCell>
                            {number(p.quantity)} {p.unit}
                          </TableCell>
                          <TableCell>{number(Number(p.min_stock))}</TableCell>
                          <TableCell>
                            <span className="tag warning">
                              {p.quantity === 0 ? "หมด" : "ใกล้หมด"}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </GridTable>
                  ) : (
                    <Empty
                      title={
                        activeProducts.length
                          ? "สต๊อกอยู่ในระดับพร้อมใช้"
                          : "เริ่มต้นจัดการสต๊อก"
                      }
                      text={
                        activeProducts.length
                          ? "ยังไม่มีสินค้าต่ำกว่าระดับขั้นต่ำในสาขาที่เลือก"
                          : "เพิ่มร้าน สาขา ผู้ขาย และสินค้าเพื่อเริ่มติดตามยอดจริง"
                      }
                      action={
                        <Button
                          variant="outline"
                          disabled={!canWrite}
                          onClick={() => navigate("settings")}
                        >
                          จัดการข้อมูลพื้นฐาน
                        </Button>
                      }
                    />
                  )}
                </article>
                <article className="panel">
                  <h2>งานประจำวัน</h2>
                  {[
                    [
                      ClipboardCheck,
                      "เช็คสต๊อกรายวัน",
                      "นับจริง เปรียบเทียบ และปรับยอด",
                      "count",
                    ],
                    [
                      ArrowDownToLine,
                      "รับสินค้าเข้า",
                      "บันทึกราคาและประวัติการรับ",
                      "receive",
                    ],
                    [
                      ShoppingCart,
                      "เตรียมรายการสั่งซื้อ",
                      "แยกตามผู้ขาย พร้อมคัดลอกข้อความ",
                      "orders",
                    ],
                  ].map(([Icon, t, s, p]) => {
                    const I = Icon as typeof Boxes;
                    return (
                      <button
                        className="quick"
                        key={String(p)}
                        onClick={() => navigate(String(p))}
                      >
                        <I size={22} />
                        <div>
                          <b>{String(t)}</b>
                          <p>{String(s)}</p>
                        </div>
                        <ChevronRight size={16} />
                      </button>
                    );
                  })}
                  <div className="mini-summary">
                    <span>ใบสั่งซื้อรอรับ</span>
                    <strong>
                      {orders.filter((o) => o.status === "ordered").length}
                    </strong>
                  </div>
                </article>
              </div>
              <article className="panel mt">
                <div className="panel-head">
                  <h2>ความเคลื่อนไหวล่าสุด</h2>
                  <Button variant="ghost" onClick={() => navigate("reports")}>
                    เปิดรายงาน
                    <ArrowRight size={14} />
                  </Button>
                </div>
                {movements.length ? (
                  <GridTable
                    heads={["วันที่", "สินค้า", "ประเภท", "จำนวน", "สาขา"]}
                  >
                    {[...movements]
                      .sort((a, b) => b.created_at.localeCompare(a.created_at))
                      .slice(0, 5)
                      .map((m) => (
                        <TableRow key={m.id}>
                          <TableCell>{dateLabel(m.created_at)}</TableCell>
                          <TableCell>
                            {products.find((p) => p.id === m.product_id)?.name}
                          </TableCell>
                          <TableCell>
                            {(
                              {
                                receive: "รับเข้า",
                                issue: "เบิกออก",
                                count: "ปรับยอดนับ",
                              } as any
                            )[m.movement_type] ?? m.movement_type}
                          </TableCell>
                          <TableCell
                            className={m.quantity < 0 ? "amber" : "green"}
                          >
                            {m.quantity > 0 ? "+" : ""}
                            {number(Number(m.quantity))}
                          </TableCell>
                          <TableCell>
                            {
                              data.branches.find((b) => b.id === m.branch_id)
                                ?.name
                            }
                          </TableCell>
                        </TableRow>
                      ))}
                  </GridTable>
                ) : (
                  <Empty
                    title="ยังไม่มีความเคลื่อนไหว"
                    text="รายการรับ เบิก และนับสต๊อกจะแสดงที่นี่"
                  />
                )}
              </article>
            </>
          )}
          {page === "stock" && (
            <section className="panel">
              {filterBar}
              <div className="panel-head">
                <h2>
                  สต๊อกแยกตามสาขา{" "}
                  <span className="muted">{filteredStock.length} รายการ</span>
                </h2>
                <Button
                  variant="outline"
                  disabled={!filteredStock.length}
                  onClick={() =>
                    exportCsv(
                      [
                        "สินค้า",
                        "สาขา",
                        "จำนวน",
                        "หน่วย",
                        "ขั้นต่ำ",
                        "เป้าหมาย",
                      ],
                      filteredStock.map((p) => [
                        p.name,
                        p.branch_name,
                        p.quantity,
                        p.unit,
                        p.min_stock,
                        p.target_stock ?? "",
                      ]),
                      "stock-" + today() + ".csv",
                    )
                  }
                >
                  <Download size={16} />
                  CSV
                </Button>
              </div>
              {filteredStock.length ? (
                <GridTable
                  heads={[
                    "สินค้า",
                    "ประเภท",
                    "สาขา",
                    "คงเหลือ",
                    "ขั้นต่ำ / เป้าหมาย",
                    "สถานะ",
                  ]}
                >
                  {filteredStock.map((p) => (
                    <TableRow key={p.id + p.branch_id}>
                      <TableCell>
                        <b>{p.name}</b>
                        <small className="subtext">{p.code ?? "—"}</small>
                      </TableCell>
                      <TableCell>
                        {categories.find((c) => c.id === p.category_id)?.name ??
                          "—"}
                      </TableCell>
                      <TableCell>{p.branch_name}</TableCell>
                      <TableCell>
                        <b>{number(p.quantity)}</b> {p.unit}
                      </TableCell>
                      <TableCell>
                        {number(Number(p.min_stock))} /{" "}
                        {p.target_stock == null
                          ? "ยังไม่กำหนด"
                          : number(Number(p.target_stock))}
                      </TableCell>
                      <TableCell>
                        <span
                          className={
                            "tag " +
                            (p.quantity <= p.min_stock ? "warning" : "ok")
                          }
                        >
                          {p.quantity === 0
                            ? "หมด"
                            : p.quantity <= p.min_stock
                              ? "ใกล้หมด"
                              : "พร้อมใช้"}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </GridTable>
              ) : (
                <Empty text="เพิ่มสินค้าและสาขา หรือปรับตัวกรองค้นหา" />
              )}
            </section>
          )}
          {(page === "receive" || page === "issue") && (
            <>
              {!ensureBranch && branchWarning}
              <form className="panel" onSubmit={submitStock}>
                <div className="form-grid">
                  <Field label="วันที่">
                    <Input
                      type="date"
                      required
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                    />
                  </Field>
                  {page === "receive" && (
                    <>
                      <Field label="รับจากใบสั่งซื้อ">
                        <Picker
                          value={receiptOrder || "none"}
                          onChange={selectReceiptOrder}
                          options={[
                            { id: "none", name: "รับเข้าโดยไม่ผูกใบสั่งซื้อ" },
                            ...orders
                              .filter((o) => o.status === "ordered")
                              .map((o) => ({
                                id: o.id,
                                name:
                                  (suppliers.find((s) => s.id === o.supplier_id)
                                    ?.name ?? "") +
                                  " · " +
                                  o.id.slice(0, 8),
                              })),
                          ]}
                          placeholder="เลือกใบสั่งซื้อรอรับ"
                        />
                      </Field>
                      <Field label="ผู้ขาย">
                        <Picker
                          disabled={!!receiptOrder}
                          value={formSupplier || "none"}
                          onChange={(v) =>
                            setFormSupplier(v === "none" ? "" : v)
                          }
                          options={[
                            { id: "none", name: "ไม่ระบุผู้ขาย" },
                            ...activeSuppliers,
                          ]}
                          placeholder="ผู้ขาย"
                        />
                      </Field>
                      <Field label="เลขที่เอกสาร / บิล">
                        <Input
                          value={docNumber}
                          onChange={(e) => setDocNumber(e.target.value)}
                          placeholder="เช่น INV-001"
                        />
                      </Field>
                    </>
                  )}
                </div>
                <div className="panel-head">
                  <h2>รายการสินค้า</h2>
                  <Button
                    type="button"
                    variant="outline"
                    disabled={!canWrite || !ensureBranch}
                    onClick={addLine}
                  >
                    <Plus size={16} />
                    เพิ่มรายการ
                  </Button>
                </div>
                {lines.length ? (
                  <GridTable
                    heads={[
                      "สินค้า",
                      "จำนวน (" +
                        (page === "receive" ? "รับเข้า" : "เบิกออก") +
                        ")",
                      "หน่วย",
                      ...(page === "receive" ? ["ราคา / หน่วยสต๊อก"] : []),
                      "",
                    ]}
                  >
                    {lines.map((line, i) => (
                      <TableRow key={i}>
                        <TableCell>
                          <Picker
                            value={line.product_id}
                            onChange={(v) => updateLine(i, "product_id", v)}
                            options={activeProducts.filter(
                              (p) =>
                                p.id === line.product_id ||
                                !lines.some((l) => l.product_id === p.id),
                            )}
                            placeholder="เลือกสินค้า"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            aria-label={`จำนวนรายการ ${i + 1}`}
                            required
                            type="number"
                            min="0.000001"
                            step="any"
                            value={line.quantity}
                            onChange={(e) =>
                              updateLine(i, "quantity", e.target.value)
                            }
                          />
                          {page === "issue" && (
                            <small className="subtext">
                              คงเหลือ{" "}
                              {number(stockFor(line.product_id, branchId))}
                            </small>
                          )}
                        </TableCell>
                        <TableCell>{line.unit || "—"}</TableCell>
                        {page === "receive" && (
                          <TableCell>
                            <Input
                              aria-label={`ราคารายการ ${i + 1}`}
                              type="number"
                              min="0"
                              step="any"
                              value={line.unit_price}
                              onChange={(e) =>
                                updateLine(i, "unit_price", e.target.value)
                              }
                              placeholder="ไม่ระบุ"
                            />
                          </TableCell>
                        )}
                        <TableCell>
                          <Button
                            type="button"
                            variant="ghost"
                            aria-label={`ลบรายการ ${i + 1}`}
                            onClick={() =>
                              setLines((ls) => ls.filter((_, j) => j !== i))
                            }
                          >
                            ×
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </GridTable>
                ) : (
                  <Empty
                    title="เพิ่มสินค้าที่จะทำรายการ"
                    text={
                      page === "receive"
                        ? "จำนวนและราคาที่กรอกใช้หน่วยสต๊อกของสินค้า"
                        : "ระบุจำนวนเบิก ระบบจะตรวจยอดคงเหลือก่อนบันทึก"
                    }
                  />
                )}
                <Field label="หมายเหตุ">
                  <Input
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder={
                      page === "issue"
                        ? "เช่น เบิกเข้าครัวรอบเช้า"
                        : "หมายเหตุการรับสินค้า"
                    }
                  />
                </Field>
                <div className="form-footer">
                  <span>ยอดสต๊อกและประวัติจะบันทึกพร้อมกัน</span>
                  <Button
                    disabled={
                      busy || !canWrite || !ensureBranch || !lines.length
                    }
                    type="submit"
                  >
                    <CheckCircle2 size={17} />
                    {busy
                      ? "กำลังบันทึก…"
                      : page === "receive"
                        ? "บันทึกรับเข้า"
                        : "บันทึกเบิกออก"}
                  </Button>
                </div>
              </form>
            </>
          )}
          {page === "count" && (
            <>
              {!ensureBranch && branchWarning}
              <section className="panel">
                <div className="toolbar">
                  <Field label="วันที่นับ">
                    <Input
                      type="date"
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                    />
                  </Field>
                  <Button
                    variant="outline"
                    disabled={busy || loading || !canWrite}
                    onClick={() => void refreshCount()}
                  >
                    <RefreshCw size={16} />
                    เริ่มนับใหม่ / โหลดล่าสุด
                  </Button>
                </div>
                <p className="note-text">
                  กรอกเฉพาะรายการที่นับแล้ว ช่องว่างจะไม่ถูกปรับยอด
                  หากมีการรับหรือเบิกระหว่างนับ ระบบจะขอให้โหลดใหม่
                </p>
                {ensureBranch && activeProducts.length ? (
                  <GridTable
                    heads={[
                      "สินค้า",
                      "ยอดก่อนนับ",
                      "นับจริง",
                      "ผลต่าง",
                      "หน่วย",
                    ]}
                  >
                    {activeProducts.map((p) => (
                      <TableRow key={p.id}>
                        <TableCell>
                          <b>{p.name}</b>
                        </TableCell>
                        <TableCell>
                          {number(
                            countSnapshot[p.id] ?? stockFor(p.id, branchId),
                          )}
                        </TableCell>
                        <TableCell>
                          <Input
                            aria-label={"ยอดนับจริง " + p.name}
                            type="number"
                            min="0"
                            step="any"
                            value={countValues[p.id] ?? ""}
                            placeholder="ยังไม่นับ"
                            onChange={(e) =>
                              setCountValues((v) => ({
                                ...v,
                                [p.id]: e.target.value,
                              }))
                            }
                          />
                        </TableCell>
                        <TableCell className="green">
                          {countValues[p.id] !== undefined &&
                          countValues[p.id] !== ""
                            ? number(
                                Number(countValues[p.id]) -
                                  (countSnapshot[p.id] ?? 0),
                              )
                            : "—"}
                        </TableCell>
                        <TableCell>{p.unit}</TableCell>
                      </TableRow>
                    ))}
                  </GridTable>
                ) : (
                  <Empty text="เลือกสาขาและเพิ่มสินค้าเพื่อเริ่มนับ" />
                )}
                <Field label="หมายเหตุ">
                  <Input
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  />
                </Field>
                <div className="form-footer">
                  <span>
                    {Object.values(countValues).filter((v) => v !== "").length}{" "}
                    รายการที่นับแล้ว
                  </span>
                  <Button
                    disabled={
                      busy ||
                      !canWrite ||
                      !ensureBranch ||
                      !Object.values(countValues).some((v) => v !== "")
                    }
                    onClick={() => void submitCount()}
                  >
                    ยืนยันและปรับยอดสต๊อก
                  </Button>
                </div>
              </section>
            </>
          )}
          {page === "orders" && (
            <>
              <Tabs defaultValue="suggested">
                <TabsList>
                  <TabsTrigger value="suggested">
                    รายการแนะนำ{" "}
                    {candidates.length > 0 ? "(" + candidates.length + ")" : ""}
                  </TabsTrigger>
                  <TabsTrigger value="saved">
                    ใบสั่งซื้อ{" "}
                    {orders.length > 0 ? "(" + orders.length + ")" : ""}
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="suggested">
                  {!ensureBranch && branchWarning}
                  <section className="panel">
                    {filterBar}
                    <p className="note-text">
                      คำนวณจากเป้าหมาย − ยอดคงเหลือ −
                      จำนวนที่อยู่ในใบสั่งซื้อรอรับ
                      แล้วปัดตามหน่วยซื้อและจำนวนต่อรอบ
                      ต้องกำหนดเป้าหมายและผู้ขายก่อน
                    </p>
                    {filteredCandidates.length ? (
                      activeSuppliers
                        .filter((s) =>
                          filteredCandidates.some(
                            (c) => c.supplier.id === s.id,
                          ),
                        )
                        .map((s) => (
                          <div className="order-group" key={s.id}>
                            <div className="panel-head">
                              <div>
                                <h2>{s.name}</h2>
                                <p>
                                  {s.contact_name ?? "ยังไม่ระบุผู้ติดต่อ"} ·
                                  LINE {s.line_name ?? s.line_id ?? "—"}
                                </p>
                              </div>
                              <Button
                                disabled={busy || !canWrite}
                                onClick={() =>
                                  setOrderEdit({
                                    supplier: s.id,
                                    lines: filteredCandidates
                                      .filter((c) => c.supplier.id === s.id)
                                      .map((c) => ({
                                        product_id: c.product.id,
                                        quantity: String(c.quantity),
                                        suggested_quantity: c.quantity,
                                        unit_price:
                                          c.price == null
                                            ? ""
                                            : String(c.price),
                                        unit: c.unit,
                                      })),
                                  })
                                }
                              >
                                <Plus size={16} />
                                ตรวจและสร้างใบสั่งซื้อ
                              </Button>
                            </div>
                            <GridTable
                              heads={[
                                "ประเภท",
                                "สินค้า",
                                "แนะนำให้สั่ง",
                                "ราคาต่อหน่วยซื้อ",
                                "ประมาณการ",
                              ]}
                            >
                              {filteredCandidates
                                .filter((c) => c.supplier.id === s.id)
                                .map((c) => (
                                  <TableRow key={c.product.id}>
                                    <TableCell>{c.category}</TableCell>
                                    <TableCell>{c.product.name}</TableCell>
                                    <TableCell>
                                      <b>{number(c.quantity)}</b> {c.unit}
                                    </TableCell>
                                    <TableCell>
                                      {c.price == null
                                        ? "ยังไม่กำหนด"
                                        : number(Number(c.price)) + " บาท"}
                                    </TableCell>
                                    <TableCell>
                                      {c.price == null
                                        ? "—"
                                        : number(c.quantity * Number(c.price)) +
                                          " บาท"}
                                    </TableCell>
                                  </TableRow>
                                ))}
                            </GridTable>
                          </div>
                        ))
                    ) : (
                      <Empty
                        title="ยังไม่มีรายการแนะนำ"
                        text={
                          ensureBranch
                            ? "สินค้ายังไม่ถึงจุดสั่งซื้อ มีใบสั่งซื้อรอรับอยู่แล้ว หรือยังไม่ได้กำหนดผู้ขายและเป้าหมาย"
                            : "เลือกสาขาเพื่อคำนวณรายการสั่งซื้อ"
                        }
                      />
                    )}
                  </section>
                </TabsContent>
                <TabsContent value="saved">
                  <section className="panel">
                    <div className="panel-head">
                      <h2>ใบสั่งซื้อของสาขาที่เลือก</h2>
                      <Button
                        variant="outline"
                        disabled={
                          !canWrite ||
                          !ensureBranch ||
                          !activeSuppliers.length ||
                          !activeProducts.length
                        }
                        onClick={() =>
                          setOrderEdit({
                            supplier: activeSuppliers[0]?.id ?? "",
                            lines: [],
                          })
                        }
                      >
                        <Plus size={16} />
                        สร้างใบสั่งซื้อเอง
                      </Button>
                    </div>
                    {orders.length ? (
                      <GridTable
                        heads={[
                          "วันที่ / เลขอ้างอิง",
                          "ผู้ขาย",
                          "สาขา",
                          "รายการ / มูลค่า",
                          "สถานะ",
                          "ดำเนินการ",
                        ]}
                      >
                        {[...orders]
                          .sort((a, b) =>
                            b.created_at.localeCompare(a.created_at),
                          )
                          .map((o) => {
                            const items = data.purchase_order_items.filter(
                              (i) => i.purchase_order_id === o.id,
                            );
                            return (
                              <TableRow key={o.id}>
                                <TableCell>
                                  {dateLabel(o.order_date)}
                                  <small className="subtext">
                                    {o.id.slice(0, 8)}
                                  </small>
                                </TableCell>
                                <TableCell>
                                  {
                                    suppliers.find(
                                      (s) => s.id === o.supplier_id,
                                    )?.name
                                  }
                                </TableCell>
                                <TableCell>
                                  {
                                    data.branches.find(
                                      (b) => b.id === o.branch_id,
                                    )?.name
                                  }
                                </TableCell>
                                <TableCell>
                                  {items.length} รายการ
                                  <small className="subtext">
                                    {items.some((i) => i.unit_price == null)
                                      ? "ราคายังไม่ครบ"
                                      : number(
                                          items.reduce(
                                            (sum, i) =>
                                              sum +
                                              Number(i.ordered_quantity) *
                                                Number(i.unit_price),
                                            0,
                                          ),
                                        ) + " บาท"}
                                  </small>
                                </TableCell>
                                <TableCell>
                                  <span
                                    className={
                                      "tag " +
                                      (o.status === "ordered"
                                        ? "ok"
                                        : "neutral")
                                    }
                                  >
                                    {statusLabel[o.status]}
                                  </span>
                                </TableCell>
                                <TableCell>
                                  <div className="row-actions">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() =>
                                        setSupplierDetail(o.supplier_id)
                                      }
                                    >
                                      ดูรายการวันนี้
                                    </Button>
                                    {o.status === "draft" && (
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        disabled={busy || !canWrite}
                                        onClick={() =>
                                          void run(
                                            "set_order_status",
                                            {
                                              id: o.id,
                                              branch_id: o.branch_id,
                                              status: "ordered",
                                            },
                                            "บันทึกว่าสั่งซื้อแล้ว",
                                          )
                                        }
                                      >
                                        สั่งแล้ว
                                      </Button>
                                    )}
                                    {["draft", "ordered"].includes(
                                      o.status,
                                    ) && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        disabled={busy || !canWrite}
                                        onClick={() => {
                                          if (confirm("ยกเลิกใบสั่งซื้อนี้?"))
                                            void run("set_order_status", {
                                              id: o.id,
                                              branch_id: o.branch_id,
                                              status: "cancelled",
                                            });
                                        }}
                                      >
                                        ยกเลิก
                                      </Button>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                      </GridTable>
                    ) : (
                      <Empty text="ตรวจรายการแนะนำ แล้วสร้างใบสั่งซื้อแยกผู้ขาย" />
                    )}
                  </section>
                </TabsContent>
              </Tabs>
            </>
          )}
          {page === "suppliers" && (
            <>
              <div className="toolbar">
                <div className="search">
                  <Search size={17} />
                  <Input
                    aria-label="ค้นหาผู้ขาย"
                    placeholder="ค้นหาผู้ขาย ผู้ติดต่อ หรือ LINE Name"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </div>
              <div className="supplier-grid">
                {suppliers
                  .filter((s) =>
                    [s.name, s.code, s.contact_name, s.line_name, s.line_id]
                      .join(" ")
                      .toLowerCase()
                      .includes(search.toLowerCase()),
                  )
                  .map((s) => {
                    const items = todaysOrders(s.id).flatMap((o) =>
                      data.purchase_order_items.filter(
                        (i) => i.purchase_order_id === o.id,
                      ),
                    );
                    return (
                      <article className="panel supplier-card" key={s.id}>
                        <div className="panel-head">
                          <div className="supplier-avatar">
                            <Users size={23} />
                          </div>
                          <span
                            className={"tag " + (s.active ? "ok" : "neutral")}
                          >
                            {s.active ? "เปิดใช้งาน" : "ปิดใช้งาน"}
                          </span>
                          <Button
                            size="icon"
                            variant="ghost"
                            aria-label={"แก้ไข " + s.name}
                            disabled={!canAdmin}
                            onClick={() => editRecord("suppliers", s)}
                          >
                            <Pencil size={16} />
                          </Button>
                        </div>
                        <h2>{s.name}</h2>
                        <p>{s.code ?? "ยังไม่ระบุรหัส"}</p>
                        <dl>
                          <div>
                            <dt>ผู้ติดต่อ</dt>
                            <dd>{s.contact_name || "—"}</dd>
                          </div>
                          <div>
                            <dt>LINE Name</dt>
                            <dd>{s.line_name || "—"}</dd>
                          </div>
                          <div>
                            <dt>LINE ID</dt>
                            <dd>{s.line_id || "—"}</dd>
                          </div>
                        </dl>
                        <div className="supplier-summary">
                          <span>รายการสั่งซื้อวันนี้</span>
                          <strong>
                            {items.length}
                            <small> รายการ</small>
                          </strong>
                        </div>
                        <Button
                          variant="outline"
                          className="full"
                          onClick={() => setSupplierDetail(s.id)}
                        >
                          ดูรายการสั่งซื้อวันนี้
                          <ArrowRight size={16} />
                        </Button>
                      </article>
                    );
                  })}
              </div>
              {!suppliers.length && (
                <section className="panel">
                  <Empty
                    title="เพิ่มผู้ขายรายแรก"
                    text="เก็บชื่อผู้ติดต่อและ LINE Name เพื่อจัดเตรียมข้อความสั่งซื้อ"
                    action={
                      <Button
                        disabled={!canAdmin}
                        onClick={() => editRecord("suppliers")}
                      >
                        <Plus size={16} />
                        เพิ่มผู้ขาย
                      </Button>
                    }
                  />
                </section>
              )}
            </>
          )}
          {page === "reports" && (
            <>
              <section className="metrics">
                {[
                  [
                    "มูลค่าสต๊อกประมาณการ",
                    number(
                      stockRows.reduce(
                        (sum, p) => sum + p.quantity * (stockPrice(p) ?? 0),
                        0,
                      ),
                    ) + " ฿",
                    "ใช้ราคาซื้อล่าสุดต่อหน่วยสต๊อก",
                  ],
                  [
                    "สินค้าไม่มีราคา",
                    String(
                      activeProducts.filter((p) => stockPrice(p) == null)
                        .length,
                    ),
                    "ยังไม่รวมในมูลค่าประมาณการ",
                  ],
                  [
                    "ใบรับสินค้า",
                    String(
                      data.goods_receipts.filter(
                        (r) =>
                          branchIds.has(r.branch_id) &&
                          r.receipt_date >= reportFrom &&
                          r.receipt_date <= reportTo,
                      ).length,
                    ),
                    "เอกสารในช่วงวันที่เลือก",
                  ],
                  [
                    "ใบนับสต๊อก",
                    String(
                      data.stock_counts.filter(
                        (r) =>
                          branchIds.has(r.branch_id) &&
                          r.count_date >= reportFrom &&
                          r.count_date <= reportTo,
                      ).length,
                    ),
                    "เอกสารในช่วงวันที่เลือก",
                  ],
                ].map(([label, value, sub]) => (
                  <article className="metric" key={label}>
                    <span>{label}</span>
                    <strong>{value}</strong>
                    <small>{sub}</small>
                  </article>
                ))}
              </section>
              <section className="panel">
                <div className="toolbar">
                  <Field label="ตั้งแต่">
                    <Input
                      type="date"
                      value={reportFrom}
                      onChange={(e) => setReportFrom(e.target.value)}
                    />
                  </Field>
                  <Field label="ถึง">
                    <Input
                      type="date"
                      min={reportFrom}
                      value={reportTo}
                      onChange={(e) => setReportTo(e.target.value)}
                    />
                  </Field>
                  <Button
                    variant="outline"
                    onClick={() => {
                      const rows = movements.filter((m) => {
                        const d = new Intl.DateTimeFormat("en-CA", {
                          timeZone: "Asia/Bangkok",
                        }).format(new Date(m.created_at));
                        return d >= reportFrom && d <= reportTo;
                      });
                      exportCsv(
                        [
                          "วันที่",
                          "สาขา",
                          "สินค้า",
                          "ประเภท",
                          "จำนวน",
                          "หน่วย",
                          "ราคาต่อหน่วย",
                          "หมายเหตุ",
                        ],
                        rows.map((m) => [
                          m.created_at,
                          data.branches.find((b) => b.id === m.branch_id)
                            ?.name ?? "",
                          products.find((p) => p.id === m.product_id)?.name ??
                            "",
                          m.movement_type,
                          m.quantity,
                          products.find((p) => p.id === m.product_id)?.unit ??
                            "",
                          m.unit_cost ?? "",
                          m.note ?? "",
                        ]),
                        "movements-" + today() + ".csv",
                      );
                    }}
                  >
                    <Download size={16} />
                    ส่งออก CSV
                  </Button>
                </div>
                <Tabs defaultValue="movements">
                  <TabsList>
                    <TabsTrigger value="movements">การเคลื่อนไหว</TabsTrigger>
                    <TabsTrigger value="counts">ผลนับสต๊อก</TabsTrigger>
                    <TabsTrigger value="prices">ประวัติราคา</TabsTrigger>
                  </TabsList>
                  <TabsContent value="movements">
                    <GridTable
                      heads={[
                        "วันที่",
                        "สาขา",
                        "สินค้า",
                        "ประเภท",
                        "จำนวน",
                        "หมายเหตุ",
                      ]}
                    >
                      {movements
                        .filter((m) => {
                          const d = new Intl.DateTimeFormat("en-CA", {
                            timeZone: "Asia/Bangkok",
                          }).format(new Date(m.created_at));
                          return d >= reportFrom && d <= reportTo;
                        })
                        .sort((a, b) =>
                          b.created_at.localeCompare(a.created_at),
                        )
                        .map((m) => (
                          <TableRow key={m.id}>
                            <TableCell>{dateLabel(m.created_at)}</TableCell>
                            <TableCell>
                              {
                                data.branches.find((b) => b.id === m.branch_id)
                                  ?.name
                              }
                            </TableCell>
                            <TableCell>
                              {
                                products.find((p) => p.id === m.product_id)
                                  ?.name
                              }
                            </TableCell>
                            <TableCell>
                              {
                                (
                                  {
                                    receive: "รับเข้า",
                                    issue: "เบิกออก",
                                    count: "นับสต๊อก",
                                    adjustment: "ปรับยอด",
                                  } as any
                                )[m.movement_type]
                              }
                            </TableCell>
                            <TableCell>
                              {number(Number(m.quantity))}{" "}
                              {
                                products.find((p) => p.id === m.product_id)
                                  ?.unit
                              }
                            </TableCell>
                            <TableCell>{m.note || "—"}</TableCell>
                          </TableRow>
                        ))}
                    </GridTable>
                  </TabsContent>
                  <TabsContent value="counts">
                    <GridTable
                      heads={[
                        "วันที่",
                        "สาขา",
                        "สินค้า",
                        "ก่อนนับ",
                        "นับจริง",
                        "ผลต่าง",
                      ]}
                    >
                      {data.stock_count_items
                        .filter((i) =>
                          data.stock_counts.some(
                            (c) =>
                              c.id === i.stock_count_id &&
                              branchIds.has(c.branch_id) &&
                              c.count_date >= reportFrom &&
                              c.count_date <= reportTo,
                          ),
                        )
                        .map((i) => {
                          const c = data.stock_counts.find(
                            (c) => c.id === i.stock_count_id,
                          );
                          return (
                            <TableRow key={i.id}>
                              <TableCell>{dateLabel(c!.count_date)}</TableCell>
                              <TableCell>
                                {
                                  data.branches.find(
                                    (b) => b.id === c?.branch_id,
                                  )?.name
                                }
                              </TableCell>
                              <TableCell>
                                {
                                  products.find((p) => p.id === i.product_id)
                                    ?.name
                                }
                              </TableCell>
                              <TableCell>
                                {number(Number(i.system_quantity))}
                              </TableCell>
                              <TableCell>
                                {number(Number(i.actual_quantity))}
                              </TableCell>
                              <TableCell>
                                {number(Number(i.variance))}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                    </GridTable>
                  </TabsContent>
                  <TabsContent value="prices">
                    <p className="note-text">
                      ราคาเป็นข้อมูลระดับองค์กร แสดงต่อหน่วยที่บันทึก
                      ไม่ขึ้นกับสาขาที่เลือก
                    </p>
                    <GridTable
                      heads={["วันที่", "สินค้า", "ผู้ขาย", "ราคา", "หน่วย"]}
                    >
                      {data.price_history
                        .filter(
                          (h) =>
                            products.some((p) => p.id === h.product_id) &&
                            h.effective_date >= reportFrom &&
                            h.effective_date <= reportTo,
                        )
                        .sort((a, b) =>
                          b.created_at.localeCompare(a.created_at),
                        )
                        .map((h) => (
                          <TableRow key={h.id}>
                            <TableCell>{dateLabel(h.effective_date)}</TableCell>
                            <TableCell>
                              {
                                products.find((p) => p.id === h.product_id)
                                  ?.name
                              }
                            </TableCell>
                            <TableCell>
                              {suppliers.find((s) => s.id === h.supplier_id)
                                ?.name ?? "—"}
                            </TableCell>
                            <TableCell>{number(Number(h.price))} บาท</TableCell>
                            <TableCell>{h.unit}</TableCell>
                          </TableRow>
                        ))}
                    </GridTable>
                  </TabsContent>
                </Tabs>
              </section>
            </>
          )}
          {page === "settings" && (
            <Tabs defaultValue="master">
              <TabsList>
                <TabsTrigger value="master">ร้านและสินค้า</TabsTrigger>
                <TabsTrigger value="prices">ราคาและผู้ขายสินค้า</TabsTrigger>
                <TabsTrigger value="template">Template สั่งซื้อ</TabsTrigger>
                <TabsTrigger value="organization">องค์กร</TabsTrigger>
                <TabsTrigger value="members">ผู้ใช้และสิทธิ์</TabsTrigger>
              </TabsList>
              <TabsContent value="master">
                <section className="panel">
                  <div className="toolbar">
                    <Picker
                      value={master}
                      onChange={setMaster}
                      options={Object.entries(masterLabels).map(
                        ([id, name]) => ({ id, name }),
                      )}
                      placeholder="ประเภทข้อมูล"
                    />
                    <div className="search">
                      <Search size={17} />
                      <Input
                        aria-label="ค้นหาข้อมูล"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder="ค้นหาชื่อหรือรหัส"
                      />
                    </div>
                    <Button
                      disabled={!canAdmin}
                      onClick={() => editRecord(master)}
                    >
                      <Plus size={16} />
                      เพิ่ม{masterLabels[master]}
                    </Button>
                  </div>
                  <p className="note-text">
                    เริ่มจากร้าน → สาขา → ผู้ขาย / ประเภท → สินค้า ตัวอย่างร้าน:
                    ก๋วยเตี๋ยวปลา ทิพย์เนตร, สยามสุกี้ ทิพย์เนตร และสยามสุกี้
                    หลัง มช.
                  </p>
                  <GridTable
                    heads={[
                      "ชื่อ / รหัส",
                      ...(master === "products"
                        ? ["หน่วย", "ผู้ขายหลัก", "ขั้นต่ำ / เป้าหมาย"]
                        : master === "branches"
                          ? ["ร้าน"]
                          : master === "suppliers"
                            ? ["ผู้ติดต่อ", "LINE Name"]
                            : []),
                      "สถานะ",
                      "",
                    ]}
                  >
                    {(
                      {
                        stores,
                        branches: data.branches.filter((b) =>
                          stores.some((s) => s.id === b.store_id),
                        ),
                        suppliers,
                        categories,
                        products,
                      } as Record<string, Row[]>
                    )[master]
                      .filter((r) =>
                        (r.name + " " + (r.code ?? ""))
                          .toLowerCase()
                          .includes(search.toLowerCase()),
                      )
                      .map((r) => (
                        <TableRow key={r.id}>
                          <TableCell>
                            <b>{r.name}</b>
                            <small className="subtext">{r.code || "—"}</small>
                          </TableCell>
                          {master === "products" && (
                            <>
                              <TableCell>{r.unit}</TableCell>
                              <TableCell>
                                {suppliers.find((s) => s.id === r.supplier_id)
                                  ?.name ?? "—"}
                              </TableCell>
                              <TableCell>
                                {r.min_stock} / {r.target_stock ?? "—"}
                              </TableCell>
                            </>
                          )}
                          {master === "branches" && (
                            <TableCell>
                              {stores.find((s) => s.id === r.store_id)?.name}
                            </TableCell>
                          )}
                          {master === "suppliers" && (
                            <>
                              <TableCell>{r.contact_name || "—"}</TableCell>
                              <TableCell>{r.line_name || "—"}</TableCell>
                            </>
                          )}
                          <TableCell>
                            <span
                              className={"tag " + (r.active ? "ok" : "neutral")}
                            >
                              {r.active ? "เปิดใช้งาน" : "ปิดใช้งาน"}
                            </span>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              disabled={!canAdmin}
                              onClick={() => editRecord(master, r)}
                            >
                              <Pencil size={14} />
                              แก้ไข
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </GridTable>
                </section>
              </TabsContent>
              <TabsContent value="prices">
                <section className="panel">
                  <div className="panel-head">
                    <div>
                      <h2>ราคาซื้อและหน่วยซื้อ</h2>
                      <p>
                        อัตราแปลง = จำนวนหน่วยสต๊อกใน 1 หน่วยซื้อ เช่น 1 ถุง = 5
                        กก.
                      </p>
                    </div>
                    <Button
                      disabled={
                        !canAdmin ||
                        !activeProducts.length ||
                        !activeSuppliers.length
                      }
                      onClick={() => setPriceOpen(true)}
                    >
                      <Plus size={16} />
                      บันทึกราคา
                    </Button>
                  </div>
                  <GridTable
                    heads={[
                      "สินค้า",
                      "ผู้ขาย",
                      "ราคาล่าสุด",
                      "หน่วยซื้อ",
                      "อัตราแปลง",
                    ]}
                  >
                    {data.supplier_products
                      .filter((s) =>
                        products.some((p) => p.id === s.product_id),
                      )
                      .map((s) => (
                        <TableRow key={s.id}>
                          <TableCell>
                            {products.find((p) => p.id === s.product_id)?.name}
                          </TableCell>
                          <TableCell>
                            {
                              suppliers.find((x) => x.id === s.supplier_id)
                                ?.name
                            }
                          </TableCell>
                          <TableCell>
                            {s.last_price == null
                              ? "—"
                              : number(Number(s.last_price)) + " บาท"}
                          </TableCell>
                          <TableCell>
                            {s.purchase_unit ||
                              products.find((p) => p.id === s.product_id)?.unit}
                          </TableCell>
                          <TableCell>
                            {number(Number(s.conversion_to_stock_unit))}{" "}
                            {products.find((p) => p.id === s.product_id)?.unit}
                          </TableCell>
                        </TableRow>
                      ))}
                  </GridTable>
                </section>
              </TabsContent>
              <TabsContent value="template">
                <section className="panel template-panel">
                  <h2>ข้อความสั่งซื้อ</h2>
                  <p>
                    ใช้ตัวแปร {"{store}, {date}, {branch}, {supplier}, {items}"}{" "}
                    ระบบจะเติมข้อมูลจากใบสั่งซื้อวันนี้ของผู้ขาย ไม่มีการส่ง
                    LINE
                  </p>
                  <Field label="Template">
                    <textarea
                      rows={9}
                      value={template}
                      onChange={(e) => setTemplate(e.target.value)}
                    />
                  </Field>
                  <div className="preview-copy">
                    <small>ตัวอย่างข้อความ</small>
                    <pre>
                      {renderTemplate(template, {
                        store: "สยามสุกี้",
                        date: dateLabel(today()),
                        branch: "ทิพย์เนตร",
                        supplier: "ผู้ขายตัวอย่าง",
                        items:
                          "เนื้อสัตว์ · หมูสันคอ 10 กก. @ 180 บาท\nผักสด · ผักกาดขาว 5 กก. @ 30 บาท",
                      })}
                    </pre>
                  </div>
                  <Button
                    disabled={busy || !canAdmin}
                    onClick={() =>
                      void run(
                        "save_template",
                        { template },
                        "บันทึก Template แล้ว",
                      )
                    }
                  >
                    บันทึก Template
                  </Button>
                </section>
              </TabsContent>
              <TabsContent value="organization">
                <section className="panel onboarding">
                  <h2>เพิ่มองค์กร</h2>
                  <p>
                    แต่ละองค์กรแยกข้อมูลจากกัน
                    ใช้ตัวเลือกด้านซ้ายเพื่อสลับพื้นที่
                  </p>
                  <Field label="ชื่อองค์กร">
                    <Input
                      value={orgName}
                      onChange={(e) => setOrgName(e.target.value)}
                    />
                  </Field>
                  <Button
                    disabled={busy || !session || !orgName.trim()}
                    onClick={() => void createOrg()}
                  >
                    สร้างองค์กรใหม่
                  </Button>
                </section>
              </TabsContent>
              <TabsContent value="members">
                <MemberSettings organizationId={orgId} userId={session?.user.id ?? ""} role={myRole} onChanged={reload} />
              </TabsContent>
            </Tabs>
          )}
          {page === "future" && (
            <div className="future-grid">
              {[
                [
                  "AI อ่านบิล",
                  "อ่านรูปบิลและช่วยเตรียมรายการรับสินค้า",
                  ReceiptText,
                ],
                [
                  "AI อ่านรูปการเบิก",
                  "อ่านภาพแล้วเตรียมรายการเบิกให้ตรวจ",
                  Sparkles,
                ],
                ["เชื่อม POS", "นำยอดขายมาใช้วิเคราะห์สต๊อก", Store],
                [
                  "Recipe / BOM",
                  "สูตรอาหารและส่วนประกอบต่อเมนู",
                  ClipboardCheck,
                ],
                ["Food Cost", "ต้นทุนวัตถุดิบต่อเมนู", BarChart3],
                [
                  "Usage Variance",
                  "เปรียบเทียบการใช้จริงกับสูตรและยอดขาย",
                  Boxes,
                ],
              ].map(([title, text, Icon]) => {
                const I = Icon as typeof Boxes;
                return (
                  <article className="panel future-card" key={String(title)}>
                    <I size={30} />
                    <span className="tag neutral">Coming Soon</span>
                    <h2>{String(title)}</h2>
                    <p>{String(text)}</p>
                  </article>
                );
              })}
            </div>
          )}
          <footer className="page-footer">
            <span>รวมร้าน · Inventory Workspace</span>
            <span>
              Phase 1 ·{" "}
              {session ? "ข้อมูลจริงจาก Supabase" : "เข้าสู่ระบบเพื่อดูข้อมูล"}
            </span>
          </footer>
        </main>
      </SidebarInset>
      <Dialog open={authOpen} onOpenChange={setAuthOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {authMode === "login" ? "เข้าสู่ระบบ" : "สร้างบัญชีผู้ใช้"}
            </DialogTitle>
            <DialogDescription>
              ใช้บัญชี Supabase สำหรับเข้าถึงข้อมูลขององค์กรคุณ
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={auth} className="stack">
            <Field label="อีเมล">
              <Input
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Field>
            <Field label="รหัสผ่าน">
              <Input
                type="password"
                autoComplete={
                  authMode === "login" ? "current-password" : "new-password"
                }
                minLength={8}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </Field>
            <Button disabled={authBusy} type="submit">
              {authBusy
                ? "กำลังดำเนินการ…"
                : authMode === "login"
                  ? "เข้าสู่ระบบ"
                  : "สร้างบัญชี"}
            </Button>
            <Button
              variant="link"
              type="button"
              onClick={() =>
                setAuthMode((m) => (m === "login" ? "signup" : "login"))
              }
            >
              {authMode === "login"
                ? "ยังไม่มีบัญชี? สร้างบัญชี"
                : "มีบัญชีแล้ว? เข้าสู่ระบบ"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!editor}
        onOpenChange={(v) => {
          if (!v && !busy) setEditor(null);
        }}
      >
        <DialogContent className="editor-dialog">
          <DialogHeader>
            <DialogTitle>
              {editor?.record.id ? "แก้ไข" : "เพิ่ม"}
              {masterLabels[editor?.entity ?? "products"]}
            </DialogTitle>
            <DialogDescription>
              ข้อมูลจะบันทึกในองค์กร {org?.name}
            </DialogDescription>
          </DialogHeader>
          {editor && (
            <form onSubmit={saveMaster} className="stack">
              <div className="form-grid">
                <Field label="ชื่อ *">
                  <Input
                    required
                    value={editor.record.name ?? ""}
                    onChange={(e) => updateRecord("name", e.target.value)}
                  />
                </Field>
                <Field label="รหัส">
                  <Input
                    value={editor.record.code ?? ""}
                    onChange={(e) => updateRecord("code", e.target.value)}
                  />
                </Field>
                {editor.entity === "branches" && (
                  <Field label="ร้าน *">
                    <Picker
                      value={editor.record.store_id ?? ""}
                      onChange={(v) => updateRecord("store_id", v)}
                      options={stores}
                      placeholder="เลือกร้าน"
                    />
                  </Field>
                )}
                {editor.entity === "suppliers" && (
                  <>
                    <Field label="ชื่อผู้ติดต่อ">
                      <Input
                        value={editor.record.contact_name ?? ""}
                        onChange={(e) =>
                          updateRecord("contact_name", e.target.value)
                        }
                      />
                    </Field>
                    <Field label="LINE Name">
                      <Input
                        value={editor.record.line_name ?? ""}
                        onChange={(e) =>
                          updateRecord("line_name", e.target.value)
                        }
                      />
                    </Field>
                    <Field label="LINE ID">
                      <Input
                        value={editor.record.line_id ?? ""}
                        onChange={(e) =>
                          updateRecord("line_id", e.target.value)
                        }
                      />
                    </Field>
                  </>
                )}
                {editor.entity === "products" && (
                  <>
                    <Field label="หน่วยสต๊อก *">
                      <Input
                        required
                        value={editor.record.unit ?? ""}
                        onChange={(e) => updateRecord("unit", e.target.value)}
                        placeholder="กก. / ถุง / ลิตร"
                      />
                    </Field>
                    <Field label="ประเภท">
                      <Picker
                        value={editor.record.category_id ?? "none"}
                        onChange={(v) =>
                          updateRecord("category_id", v === "none" ? null : v)
                        }
                        options={[
                          { id: "none", name: "ไม่ระบุประเภท" },
                          ...categories,
                        ]}
                      />
                    </Field>
                    <Field label="ผู้ขายหลัก">
                      <Picker
                        value={editor.record.supplier_id ?? "none"}
                        onChange={(v) =>
                          updateRecord("supplier_id", v === "none" ? null : v)
                        }
                        options={[
                          { id: "none", name: "ยังไม่ระบุ" },
                          ...suppliers,
                        ]}
                      />
                    </Field>
                    <Field label="สต๊อกขั้นต่ำ">
                      <Input
                        type="number"
                        min="0"
                        step="any"
                        required
                        value={editor.record.min_stock ?? 0}
                        onChange={(e) =>
                          updateRecord("min_stock", e.target.value)
                        }
                      />
                    </Field>
                    <Field label="สต๊อกเป้าหมาย">
                      <Input
                        type="number"
                        min="0"
                        step="any"
                        value={editor.record.target_stock ?? ""}
                        onChange={(e) =>
                          updateRecord(
                            "target_stock",
                            e.target.value === "" ? null : e.target.value,
                          )
                        }
                      />
                    </Field>
                    <Field label="จำนวนต่อรอบสั่ง (หน่วยซื้อ)">
                      <Input
                        type="number"
                        min="0.000001"
                        step="any"
                        value={editor.record.reorder_multiple ?? ""}
                        onChange={(e) =>
                          updateRecord(
                            "reorder_multiple",
                            e.target.value === "" ? null : e.target.value,
                          )
                        }
                      />
                    </Field>
                  </>
                )}
                {["products", "suppliers"].includes(editor.entity) && (
                  <Field label="หมายเหตุ">
                    <Input
                      value={editor.record.notes ?? ""}
                      onChange={(e) => updateRecord("notes", e.target.value)}
                    />
                  </Field>
                )}
              </div>
              <label className="check-field">
                <Checkbox
                  checked={editor.record.active ?? true}
                  onCheckedChange={(v) => updateRecord("active", v === true)}
                />
                เปิดใช้งาน
              </label>
              <Button type="submit" disabled={busy || !canAdmin}>
                {busy ? "กำลังบันทึก…" : "บันทึก"}
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={priceOpen} onOpenChange={setPriceOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>บันทึกราคาสินค้า</DialogTitle>
            <DialogDescription>
              เก็บราคาล่าสุดและประวัติราคาแยกตามผู้ขาย
            </DialogDescription>
          </DialogHeader>
          <form
            className="stack"
            onSubmit={async (e) => {
              e.preventDefault();
              if (
                await run("save_price", {
                  ...priceForm,
                  price: Number(priceForm.price),
                  conversion: Number(priceForm.conversion),
                })
              )
                setPriceOpen(false);
            }}
          >
            <Field label="สินค้า">
              <Picker
                value={priceForm.product_id}
                onChange={(v) =>
                  setPriceForm((f) => ({
                    ...f,
                    product_id: v,
                    unit: products.find((p) => p.id === v)?.unit ?? "",
                  }))
                }
                options={activeProducts}
                placeholder="เลือกสินค้า"
              />
            </Field>
            <Field label="ผู้ขาย">
              <Picker
                value={priceForm.supplier_id}
                onChange={(v) =>
                  setPriceForm((f) => ({ ...f, supplier_id: v }))
                }
                options={activeSuppliers}
                placeholder="เลือกผู้ขาย"
              />
            </Field>
            <div className="form-grid">
              {[
                ["price", "ราคา", "number"],
                ["unit", "หน่วยซื้อ", "text"],
                ["conversion", "อัตราแปลงเป็นหน่วยสต๊อก", "number"],
                ["date", "วันที่ราคา", "date"],
              ].map(([key, label, type]) => (
                <Field label={label} key={key}>
                  <Input
                    required
                    type={type}
                    min={key === "conversion" ? "0.000001" : "0"}
                    step="any"
                    value={(priceForm as any)[key]}
                    onChange={(e) =>
                      setPriceForm((f) => ({ ...f, [key]: e.target.value }))
                    }
                  />
                </Field>
              ))}
            </div>
            <Button
              type="submit"
              disabled={busy || !canAdmin || !priceForm.product_id || !priceForm.supplier_id}
            >
              บันทึกราคา
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!supplierDetail}
        onOpenChange={(v) => {
          if (!v) setSupplierDetail(null);
        }}
      >
        <DialogContent className="wide-dialog">
          <DialogHeader>
            <DialogTitle>
              {suppliers.find((s) => s.id === supplierDetail)?.name} ·
              สั่งซื้อวันนี้
            </DialogTitle>
            <DialogDescription>
              {dateLabel(today())} · ตามร้าน/สาขาที่เลือก ·
              คัดลอกข้อความเพื่อส่งด้วยตัวเอง
            </DialogDescription>
          </DialogHeader>
          {supplierDetail && (
            <>
              {todaysOrders(supplierDetail).length ? (
                <>
                  <GridTable
                    heads={[
                      "สาขา",
                      "ประเภท",
                      "สินค้า",
                      "จำนวน",
                      "ราคา / หน่วย",
                    ]}
                  >
                    {todaysOrders(supplierDetail).flatMap((o) =>
                      data.purchase_order_items
                        .filter((i) => i.purchase_order_id === o.id)
                        .map((i) => {
                          const p = products.find((p) => p.id === i.product_id);
                          return (
                            <TableRow key={i.id}>
                              <TableCell>
                                {
                                  data.branches.find(
                                    (b) => b.id === o.branch_id,
                                  )?.name
                                }
                              </TableCell>
                              <TableCell>
                                {categories.find((c) => c.id === p?.category_id)
                                  ?.name ?? "—"}
                              </TableCell>
                              <TableCell>{p?.name}</TableCell>
                              <TableCell>
                                {number(Number(i.ordered_quantity))} {i.unit}
                              </TableCell>
                              <TableCell>
                                {i.unit_price == null
                                  ? "ยังไม่กำหนด"
                                  : number(Number(i.unit_price)) + " บาท"}
                              </TableCell>
                            </TableRow>
                          );
                        }),
                    )}
                  </GridTable>
                  <Field label="ข้อความพร้อมคัดลอก">
                    <textarea
                      readOnly
                      rows={8}
                      value={orderText(supplierDetail)}
                    />
                  </Field>
                  <Button onClick={() => void copyOrder(supplierDetail)}>
                    <Copy size={16} />
                    คัดลอกข้อความสั่งซื้อ
                  </Button>
                </>
              ) : (
                <Empty
                  title="ยังไม่มีใบสั่งซื้อวันนี้"
                  text="สร้างใบสั่งซื้อจากหน้า รายการสั่งซื้อ แล้วกลับมาคัดลอกข้อความ"
                  action={
                    <Button
                      onClick={() => {
                        setSupplierDetail(null);
                        navigate("orders");
                      }}
                    >
                      ไปที่รายการสั่งซื้อ
                    </Button>
                  }
                />
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!orderEdit}
        onOpenChange={(v) => {
          if (!v && !busy) setOrderEdit(null);
        }}
      >
        <DialogContent className="wide-dialog">
          <DialogHeader>
            <DialogTitle>ตรวจใบสั่งซื้อก่อนบันทึก</DialogTitle>
            <DialogDescription>
              {store?.name} · {branch?.name} · จำนวนเป็นหน่วยซื้อ
            </DialogDescription>
          </DialogHeader>
          {orderEdit && (
            <form
              className="stack"
              onSubmit={async (e) => {
                e.preventDefault();
                if (
                  await run(
                    "create_order",
                    {
                      branch_id: branchId,
                      supplier_id: orderEdit.supplier,
                      date: today(),
                      items: orderEdit.lines.map((l) => ({
                        ...l,
                        quantity: Number(l.quantity),
                        unit_price:
                          l.unit_price === "" ? null : Number(l.unit_price),
                      })),
                    },
                    "สร้างใบสั่งซื้อแล้ว",
                  )
                )
                  setOrderEdit(null);
              }}
            >
              <Picker
                value={orderEdit.supplier}
                onChange={(v) => setOrderEdit({ supplier: v, lines: [] })}
                options={activeSuppliers}
                placeholder="เลือกผู้ขาย"
              />
              <GridTable
                heads={["สินค้า", "จำนวนซื้อ", "หน่วยซื้อ", "ราคา / หน่วย", ""]}
              >
                {orderEdit.lines.map((l, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Picker
                        value={l.product_id}
                        onChange={(v) => {
                          const p = products.find((p) => p.id === v);
                          const sp = data.supplier_products.find(
                            (s) =>
                              s.product_id === v &&
                              s.supplier_id === orderEdit.supplier,
                          );
                          setOrderEdit((o) =>
                            o
                              ? {
                                  ...o,
                                  lines: o.lines.map((x, j) =>
                                    j === i
                                      ? {
                                          ...x,
                                          product_id: v,
                                          unit:
                                            sp?.purchase_unit ?? p?.unit ?? "",
                                          unit_price:
                                            sp?.last_price == null
                                              ? ""
                                              : String(sp.last_price),
                                        }
                                      : x,
                                  ),
                                }
                              : o,
                          );
                        }}
                        options={activeProducts.filter(
                          (p) =>
                            (p.supplier_id === orderEdit.supplier ||
                              data.supplier_products.some(
                                (s) =>
                                  s.product_id === p.id &&
                                  s.supplier_id === orderEdit.supplier,
                              )) &&
                            (p.id === l.product_id ||
                              !orderEdit.lines.some(
                                (x) => x.product_id === p.id,
                              )),
                        )}
                        placeholder="เลือกสินค้า"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0.000001"
                        step="any"
                        required
                        value={l.quantity}
                        aria-label={"จำนวนสั่ง " + (i + 1)}
                        onChange={(e) =>
                          setOrderEdit((o) =>
                            o
                              ? {
                                  ...o,
                                  lines: o.lines.map((x, j) =>
                                    j === i
                                      ? { ...x, quantity: e.target.value }
                                      : x,
                                  ),
                                }
                              : o,
                          )
                        }
                      />
                    </TableCell>
                    <TableCell>{l.unit}</TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        step="any"
                        value={l.unit_price}
                        aria-label={"ราคาสั่ง " + (i + 1)}
                        placeholder="ไม่ระบุ"
                        onChange={(e) =>
                          setOrderEdit((o) =>
                            o
                              ? {
                                  ...o,
                                  lines: o.lines.map((x, j) =>
                                    j === i
                                      ? { ...x, unit_price: e.target.value }
                                      : x,
                                  ),
                                }
                              : o,
                          )
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <Button
                        type="button"
                        variant="ghost"
                        aria-label={"ลบรายการสั่ง " + (i + 1)}
                        onClick={() =>
                          setOrderEdit((o) =>
                            o
                              ? {
                                  ...o,
                                  lines: o.lines.filter((_, j) => j !== i),
                                }
                              : o,
                          )
                        }
                      >
                        ×
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </GridTable>
              <Button
                variant="outline"
                type="button"
                onClick={() =>
                  setOrderEdit((o) =>
                    o
                      ? {
                          ...o,
                          lines: [
                            ...o.lines,
                            {
                              product_id: "",
                              quantity: "",
                              unit: "",
                              unit_price: "",
                            },
                          ],
                        }
                      : o,
                  )
                }
              >
                <Plus size={16} />
                เพิ่มสินค้า
              </Button>
              <Button
                type="submit"
                disabled={
                  busy ||
                  !ensureBranch ||
                  !orderEdit.lines.length ||
                  orderEdit.lines.some((l) => !l.product_id || !l.quantity)
                }
              >
                บันทึกใบสั่งซื้อร่าง
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </SidebarProvider>
  );
}
